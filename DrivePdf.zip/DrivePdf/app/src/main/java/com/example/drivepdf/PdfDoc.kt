package com.example.drivepdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
import kotlin.math.sqrt

class Rendered(val bitmap: Bitmap, val sizeChanged: Boolean)

class PdfDoc(file: File) {
    private val pfd: ParcelFileDescriptor =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = try {
        PdfRenderer(pfd)
    } catch (e: Exception) {
        pfd.close()
        throw e
    }
    private val lock = Any()

    @Volatile
    private var closed = false

    val pageCount: Int = renderer.pageCount
    private val sizeArr = arrayOfNulls<IntArray>(pageCount)

    init {
        // only page 1 is read at open: that is all we need to show the first screen
        if (pageCount > 0) sizeArr[0] = readSize(0)
    }

    private fun readSize(i: Int): IntArray = synchronized(lock) {
        if (closed) throw IllegalStateException("closed")
        val p = renderer.openPage(i)
        try {
            intArrayOf(p.width, p.height)
        } finally {
            p.close()
        }
    }

    /** Size of a page in PDF points. Pages not rendered yet are assumed to match page 1. */
    fun sizeOf(i: Int): IntArray = sizeArr[i] ?: sizeArr[0] ?: intArrayOf(595, 842)

    /** Renders a page. The real page size is learned here for free, no extra pass over the file. */
    fun render(index: Int, widthPx: Int): Rendered = synchronized(lock) {
        if (closed) throw IllegalStateException("closed")
        val page = renderer.openPage(index)
        try {
            val est = sizeOf(index)
            val real = intArrayOf(page.width, page.height)
            sizeArr[index] = real
            val changed = est[0] != real[0] || est[1] != real[1]

            var w = widthPx.coerceAtLeast(1)
            var h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val maxPixels = 9_000_000.0
            if (w.toDouble() * h > maxPixels) {
                val f = sqrt(maxPixels / (w.toDouble() * h)).toFloat()
                w = (w * f).toInt().coerceAtLeast(1)
                h = (h * f).toInt().coerceAtLeast(1)
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            Rendered(bmp, changed)
        } finally {
            page.close()
        }
    }

    fun close() = synchronized(lock) {
        if (!closed) {
            closed = true
            try { renderer.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
        }
    }
}

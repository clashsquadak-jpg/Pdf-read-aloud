package com.example.drivepdf

import android.graphics.Bitmap
import android.graphics.Color
import android.util.LruCache
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.min

class PageAdapter(
    private val doc: PdfDoc,
    itemWidth: Int,
    private val sideMargin: Int,
    private val vMargin: Int,
    startPage: Int
) : RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(val img: ImageView) : RecyclerView.ViewHolder(img) {
        var index = -1
    }

    var itemWidth: Int = itemWidth
        private set

    private var contentWidth = (itemWidth - 2 * sideMargin).coerceAtLeast(1)
    private var quality = 1f
    private val holders = HashMap<Int, VH>()

    // prefix[i] = total height (px) of all pages before page i; used by the fast scroller
    private var prefix = LongArray(0)
    private var prefixDirty = true

    private val cache = object : LruCache<Int, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 4).toInt()
    ) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    private val renderer = PageRenderer(doc, startPage) { pos, bmp, changed ->
        onRendered(pos, bmp, changed)
    }

    private fun wantedWidth(): Int = min((contentWidth * quality).toInt(), 2400).coerceAtLeast(1)

    private fun needs(pos: Int): Boolean {
        val b = cache.get(pos)
        return b == null || b.width < wantedWidth() * 0.9f
    }

    private fun onRendered(pos: Int, bmp: Bitmap, sizeChanged: Boolean) {
        val old = cache.get(pos)
        if (old == null || old.width < bmp.width) cache.put(pos, bmp)
        if (sizeChanged) {
            // this page is not the size we guessed: re-measure it (rare, only for mixed-size PDFs)
            prefixDirty = true
            notifyItemChanged(pos)
            return
        }
        val h = holders[pos]
        if (h != null && h.index == pos) h.img.setImageBitmap(cache.get(pos))
    }

    // ---------- geometry (for the fast scroller) ----------

    private fun pageHeight(i: Int): Int {
        val s = doc.sizeOf(i)
        val ratio = if (s[0] > 0) s[1].toFloat() / s[0] else 1.414f
        return (contentWidth * ratio).toInt()
    }

    private fun ensurePrefix() {
        if (!prefixDirty && prefix.size == itemCount + 1) return
        val n = itemCount
        val a = LongArray(n + 1)
        for (i in 0 until n) a[i + 1] = a[i] + pageHeight(i) + 2 * vMargin
        prefix = a
        prefixDirty = false
    }

    /** Distance from the top of the document to the top of page [i], in px. */
    fun prefixAt(i: Int): Long {
        ensurePrefix()
        return prefix[i.coerceIn(0, itemCount)]
    }

    fun totalHeight(): Long {
        ensurePrefix()
        return prefix[itemCount]
    }

    /** Which page contains the point [y] px from the top of the document. */
    fun pageAtY(y: Long): Int {
        ensurePrefix()
        var lo = 0
        var hi = itemCount - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (prefix[mid] <= y) lo = mid else hi = mid - 1
        }
        return lo
    }

    // ---------- control ----------

    /** Tell the renderer which pages are on screen so it renders those first. */
    fun setWindow(first: Int, last: Int) = renderer.setWindow(first, last)

    /** 1f = sharp at normal size, 2f = sharp when zoomed in. Old bitmaps stay visible until new ones arrive. */
    fun setQuality(q: Float) {
        if (q == quality) return
        quality = q
        for ((pos, _) in holders) {
            if (needs(pos)) renderer.request(pos, wantedWidth())
        }
    }

    /** The pane got wider or narrower (split view, rotation). */
    fun setItemWidth(w: Int) {
        itemWidth = w
        contentWidth = (w - 2 * sideMargin).coerceAtLeast(1)
        prefixDirty = true
        notifyDataSetChanged()
    }

    fun close() {
        renderer.stop()
        cache.evictAll()
        holders.clear()
    }

    override fun getItemCount() = doc.pageCount

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val iv = ImageView(parent.context)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        iv.setBackgroundColor(Color.WHITE)
        return VH(iv)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        if (h.index >= 0 && holders[h.index] === h) holders.remove(h.index)
        h.index = position
        holders[position] = h

        val height = pageHeight(position)
        val old = h.img.layoutParams as? RecyclerView.LayoutParams
        if (old == null || old.width != contentWidth || old.height != height) {
            val lp = RecyclerView.LayoutParams(contentWidth, height)
            lp.setMargins(sideMargin, vMargin, sideMargin, vMargin)
            h.img.layoutParams = lp
        }

        h.img.setImageBitmap(cache.get(position))
        val w = wantedWidth()
        if (needs(position)) renderer.request(position, w)
        // get the neighbours ready so scrolling never shows a blank page
        if (position + 1 < itemCount && needs(position + 1)) renderer.request(position + 1, w)
        if (position + 2 < itemCount && needs(position + 2)) renderer.request(position + 2, w)
        if (position - 1 >= 0 && needs(position - 1)) renderer.request(position - 1, w)
    }

    override fun onViewRecycled(h: VH) {
        if (h.index >= 0 && holders[h.index] === h) holders.remove(h.index)
        h.index = -1
        h.img.setImageDrawable(null)
    }
}

package com.example.drivepdf

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.media.AudioAttributesCompat
import androidx.media.AudioFocusRequestCompat
import androidx.media.AudioManagerCompat
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Reads a PDF aloud. Runs as a foreground media service so it keeps going with the screen off,
 * can be controlled from the notification, lock screen and earphone buttons, and pauses for calls.
 */
class ReadAloudService : Service() {

    companion object {
        const val ACTION_START = "com.example.drivepdf.READ_START"
        const val ACTION_TOGGLE = "com.example.drivepdf.READ_TOGGLE"
        const val ACTION_PLAY = "com.example.drivepdf.READ_PLAY"
        const val ACTION_PAUSE = "com.example.drivepdf.READ_PAUSE"
        const val ACTION_NEXT = "com.example.drivepdf.READ_NEXT"
        const val ACTION_PREV = "com.example.drivepdf.READ_PREV"
        const val ACTION_STOP = "com.example.drivepdf.READ_STOP"
        const val EXTRA_PATH = "path"
        const val EXTRA_NAME = "name"
        const val EXTRA_PAGE = "page"

        private const val CHANNEL_ID = "read_aloud"
        private const val NOTIF_ID = 4242
        private val ID_RE = Regex("""g(\d+)_([sp])(\d+)""")

        @Volatile
        var instance: ReadAloudService? = null
            private set
    }

    private class Seg(val page: Int, val raw: String, val speak: String, val para: Int, val pauseMs: Int)

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("read", MODE_PRIVATE) }

    // speech engine
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // phone integration
    private lateinit var session: MediaSessionCompat
    private lateinit var audioManager: AudioManager
    private var focusReq: AudioFocusRequestCompat? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var noisyRegistered = false
    private var resumeOnGain = false

    // text
    private val extractExec = Executors.newSingleThreadExecutor()
    private var extractor: PdfTextExtractor? = null
    private var readId = 0
    private var path = ""
    private var docName = ""
    private var pageCount = 0
    private var startPage = 0
    private var nextExtract = 0
    private var extracting = false
    private var paraBase = 0
    private val segments = ArrayList<Seg>()
    private val pageStart = HashMap<Int, Int>()
    private val pageParts = HashMap<Int, Int>()

    // playback position
    private var cursor = 0
    private var queued = 0
    private var gen = 0
    private var completedIdx = -1
    private var active = false
    private var wantPlay = false
    private var started = false
    private var loading = false
    private var waitingForText = false
    private var pendingJump = -1
    private var errors = 0
    private var sleepMinutes = 0

    var rate = 1f
        private set
    var pitch = 1f
        private set

    // earphone buttons
    private var tapCount = 0
    private val tapRunnable = Runnable {
        val n = tapCount
        tapCount = 0
        when {
            n <= 1 -> togglePlayPause()
            n == 2 -> next()
            else -> previous()
        }
    }

    private val sleepRunnable = Runnable { finishReading("Sleep timer ended the reading") }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        instance = this
        rate = prefs.getFloat("rate", 1f)
        pitch = prefs.getFloat("pitch", 1f)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        createChannel()
        session = MediaSessionCompat(this, "DrivePdfReadAloud")
        session.setFlags(
            MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
        )
        session.setCallback(sessionCallback)
        initTts(true)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (!ensureForeground()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startReading(
                    intent?.getStringExtra(EXTRA_PATH) ?: "",
                    intent?.getStringExtra(EXTRA_NAME) ?: "document",
                    intent?.getIntExtra(EXTRA_PAGE, 0) ?: 0
                )
            }
            ACTION_TOGGLE -> togglePlayPause()
            ACTION_PLAY -> play()
            ACTION_PAUSE -> pause()
            ACTION_NEXT -> next()
            ACTION_PREV -> previous()
            ACTION_STOP -> stopReading()
            else -> if (!active) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        gen++
        handler.removeCallbacksAndMessages(null)
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Throwable) {
        }
        val ex = extractor
        if (ex != null) extractExec.execute { ex.close() }
        extractExec.shutdown()
        try {
            session.isActive = false
            session.release()
        } catch (_: Throwable) {
        }
        abandonFocus()
        releaseLocks()
        unregisterNoisy()
        if (instance === this) instance = null
        if (ReadAloud.state.active) ReadAloud.publish(ReadAloud.State())
    }

    // ------------------------------------------------------------------ starting

    private fun startReading(file: String, name: String, page: Int) {
        gen++
        tts?.stop()
        handler.removeCallbacks(tapRunnable)
        readId++
        val old = extractor
        if (old != null) extractExec.execute { old.close() }
        extractor = null
        segments.clear()
        pageStart.clear()
        pageParts.clear()
        path = file
        docName = name
        startPage = page
        nextExtract = page
        extracting = false
        paraBase = 0
        pageCount = 0
        cursor = 0
        queued = 0
        completedIdx = -1
        started = false
        waitingForText = false
        pendingJump = -1
        errors = 0
        active = true
        wantPlay = true
        loading = true
        requestFocus()
        acquireLocks()
        registerNoisy()
        session.isActive = true
        updatePlaybackState()
        updateMetadata("")
        publish(null)
        refreshNotification()

        val id = readId
        extractExec.execute {
            try {
                val ex = PdfTextExtractor(applicationContext, File(file))
                handler.post {
                    if (id == readId) {
                        extractor = ex
                        pageCount = ex.pageCount
                        pumpExtraction()
                    } else {
                        extractExec.execute { ex.close() }
                    }
                }
            } catch (t: Throwable) {
                handler.post {
                    if (id == readId) finishReading("Couldn't read the text of this PDF (it may be protected)")
                }
            }
        }
    }

    private fun finishedText(): Boolean = extractor != null && !extracting && nextExtract >= pageCount

    private fun pumpExtraction() {
        val ex = extractor ?: return
        if (extracting || nextExtract >= pageCount) return
        val readPage = if (cursor < segments.size) segments[cursor].page else startPage
        val needMore = segments.size - cursor < 6
        if (!(nextExtract <= readPage + 3 || needMore)) return
        extracting = true
        val p = nextExtract
        val id = readId
        extractExec.execute {
            val drafts = try {
                ex.extractPage(p)
            } catch (t: Throwable) {
                emptyList()
            }
            handler.post { if (id == readId) onPageExtracted(p, drafts) }
        }
    }

    private fun onPageExtracted(p: Int, drafts: List<SegDraft>) {
        extracting = false
        nextExtract = p + 1
        if (drafts.isNotEmpty()) {
            pageStart[p] = segments.size
            pageParts[p] = drafts.size
            var maxPara = -1
            for (d in drafts) {
                segments.add(Seg(p, d.raw, d.speak, paraBase + d.para, d.pauseMs))
                if (d.para > maxPara) maxPara = d.para
            }
            paraBase += maxPara + 1
        }

        if (segments.isEmpty() && finishedText()) {
            finishReading("No readable text found. A scanned PDF has only pictures of text.")
            return
        }
        if (!started && wantPlay && ttsReady && segments.isNotEmpty()) {
            loading = false
            speakFrom(0)
        } else if (segments.isNotEmpty()) {
            loading = false
        }
        if (waitingForText && queued < segments.size) {
            waitingForText = false
            enqueueLookahead()
        }
        if (pendingJump >= 0) {
            if (pendingJump < segments.size) {
                val j = pendingJump
                pendingJump = -1
                speakFrom(j)
            } else if (finishedText()) {
                pendingJump = -1
                finishReading("Finished reading")
                return
            }
        }
        pumpExtraction()
        checkFinished()
        publish(null)
    }

    // ------------------------------------------------------------------ speaking

    private fun speakFrom(index: Int) {
        val t = tts ?: return
        if (index < 0 || index >= segments.size) return
        gen++
        started = true
        loading = false
        cursor = index
        queued = index
        completedIdx = index - 1
        t.stop()
        enqueue(queued++, TextToSpeech.QUEUE_FLUSH)
        enqueueLookahead()
        updatePlaybackState()
        publish(null)
    }

    private fun enqueue(i: Int, mode: Int) {
        val t = tts ?: return
        val seg = segments[i]
        val r = t.speak(seg.speak, mode, null, "g${gen}_s$i")
        if (r == TextToSpeech.ERROR) {
            onSpeakError(i)
            return
        }
        if (seg.pauseMs > 0) {
            t.playSilentUtterance(seg.pauseMs.toLong(), TextToSpeech.QUEUE_ADD, "g${gen}_p$i")
        }
    }

    /** Keeps the next part queued behind the one being spoken, so there is no gap between parts. */
    private fun enqueueLookahead() {
        while (queued <= cursor + 1 && queued < segments.size) enqueue(queued++, TextToSpeech.QUEUE_ADD)
        if (queued <= cursor + 1 && queued >= segments.size && !finishedText()) waitingForText = true
        pumpExtraction()
    }

    private fun parseId(id: String?): Triple<Int, Char, Int>? {
        val m = ID_RE.matchEntire(id ?: return null) ?: return null
        return Triple(m.groupValues[1].toInt(), m.groupValues[2][0], m.groupValues[3].toInt())
    }

    private fun onUttStart(id: String?) {
        val (g, type, i) = parseId(id) ?: return
        if (g != gen || type != 's' || i >= segments.size) return
        cursor = i
        errors = 0
        enqueueLookahead()
        publish(null)
        updateMetadata(segments[i].raw)
        refreshNotification()
    }

    private fun onUttDone(id: String?) {
        val (g, type, i) = parseId(id) ?: return
        if (g != gen || i >= segments.size) return
        if (type == 'p' || segments[i].pauseMs == 0) {
            if (i > completedIdx) completedIdx = i
            checkFinished()
        }
    }

    private fun onUttError(id: String?) {
        val (g, _, i) = parseId(id) ?: return
        if (g != gen) return
        onSpeakError(i)
    }

    private fun onSpeakError(i: Int) {
        errors++
        if (errors > 4) {
            finishReading("The voice had a problem. Try another voice.")
            return
        }
        if (i + 1 < segments.size) speakFrom(i + 1) else checkFinished()
    }

    private fun checkFinished() {
        if (started && wantPlay && completedIdx >= segments.size - 1 && finishedText()) {
            finishReading("Finished reading")
        }
    }

    // ------------------------------------------------------------------ controls

    fun togglePlayPause() {
        if (wantPlay) pause() else play()
    }

    fun pause(keepFocus: Boolean = false) {
        if (!active || !wantPlay) return
        wantPlay = false
        gen++
        tts?.stop()
        releaseLocks()
        if (!keepFocus) abandonFocus()
        updatePlaybackState()
        publish(null)
        refreshNotification(true)
    }

    fun play() {
        if (!active || wantPlay) return
        wantPlay = true
        requestFocus()
        acquireLocks()
        if (started && cursor < segments.size) {
            speakFrom(cursor)
        } else if (ttsReady && segments.isNotEmpty()) {
            speakFrom(0)
        }
        updatePlaybackState()
        publish(null)
        refreshNotification(true)
    }

    fun next() {
        if (active) jumpTo(cursor + 1)
    }

    fun previous() {
        if (active) jumpTo((cursor - 1).coerceAtLeast(0))
    }

    fun nextParagraph() {
        if (!active) return
        val cur = segments.getOrNull(cursor) ?: return
        var i = cursor + 1
        while (i < segments.size && segments[i].para == cur.para) i++
        jumpTo(i)
    }

    fun previousParagraph() {
        if (!active) return
        val cur = segments.getOrNull(cursor) ?: return
        var start = cursor
        while (start > 0 && segments[start - 1].para == cur.para) start--
        if (cursor > start) {
            jumpTo(start)
        } else if (start > 0) {
            val prevPara = segments[start - 1].para
            var j = start - 1
            while (j > 0 && segments[j - 1].para == prevPara) j--
            jumpTo(j)
        } else {
            jumpTo(0)
        }
    }

    private fun jumpTo(idx: Int) {
        if (!wantPlay) {
            wantPlay = true
            requestFocus()
            acquireLocks()
        }
        when {
            idx < segments.size -> {
                pendingJump = -1
                speakFrom(idx)
            }
            !finishedText() -> {
                pendingJump = idx
                gen++
                tts?.stop()
                pumpExtraction()
            }
            else -> finishReading("Finished reading")
        }
        updatePlaybackState()
        refreshNotification(true)
    }

    fun stopReading() {
        finishReading(null)
    }

    private fun finishReading(msg: String?) {
        if (!active && msg == null) {
            stopSelf()
            return
        }
        gen++
        handler.removeCallbacks(sleepRunnable)
        handler.removeCallbacks(tapRunnable)
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
        active = false
        wantPlay = false
        loading = false
        sleepMinutes = 0
        abandonFocus()
        releaseLocks()
        unregisterNoisy()
        try {
            session.isActive = false
        } catch (_: Throwable) {
        }
        publish(msg)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------ voice settings

    fun setRate(r: Float) {
        rate = r.coerceIn(0.5f, 3f)
        prefs.edit().putFloat("rate", rate).apply()
        tts?.setSpeechRate(rate)
        applyAndHear()
        publish(null)
    }

    fun setPitch(p: Float) {
        pitch = p.coerceIn(0.6f, 1.4f)
        prefs.edit().putFloat("pitch", pitch).apply()
        tts?.setPitch(pitch)
        applyAndHear()
    }

    fun setSleepTimer(minutes: Int) {
        handler.removeCallbacks(sleepRunnable)
        sleepMinutes = minutes
        if (minutes > 0) handler.postDelayed(sleepRunnable, minutes * 60_000L)
    }

    fun sleepTimerMinutes(): Int = sleepMinutes

    fun setVoice(name: String) {
        val t = tts ?: return
        val v = englishVoices().firstOrNull { it.name == name } ?: return
        try {
            t.setVoice(v)
        } catch (_: Exception) {
            return
        }
        prefs.edit().putString("voice", name).apply()
        applyAndHear()
    }

    /** Restart the current part so a new voice / speed is heard straight away; preview when not playing. */
    private fun applyAndHear() {
        val t = tts ?: return
        if (active && wantPlay && started && cursor < segments.size) {
            speakFrom(cursor)
        } else {
            gen++
            t.stop()
            t.speak("Hello. This is how I will read your PDF aloud.", TextToSpeech.QUEUE_FLUSH, null, "preview")
        }
    }

    fun voiceOptions(): List<ReadAloud.VoiceOption> {
        if (!ttsReady) return emptyList()
        val voices = englishVoices()
        val current = try {
            tts?.voice?.name
        } catch (_: Exception) {
            null
        } ?: prefs.getString("voice", null)
        val order = listOf("IN", "GB", "AU", "US")
        val sorted = voices.sortedWith(
            compareBy<Voice>(
                { val i = order.indexOf(it.locale.country); if (i < 0) 99 else i },
                { it.locale.country },
                { it.name }
            )
        )
        val counters = HashMap<String, Int>()
        return sorted.map { v ->
            val country = v.locale.displayCountry.ifBlank { "English" }
            val n = (counters[country] ?: 0) + 1
            counters[country] = n
            val tags = ArrayList<String>()
            tags.add(if (v.isNetworkConnectionRequired) "online" else "offline")
            if (v.quality >= Voice.QUALITY_VERY_HIGH) tags.add("very high quality")
            else if (v.quality >= Voice.QUALITY_HIGH) tags.add("high quality")
            ReadAloud.VoiceOption(v.name, "$country · Voice $n (${tags.joinToString(", ")})", v.name == current)
        }
    }

    // ------------------------------------------------------------------ text to speech engine

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun initTts(preferGoogle: Boolean) {
        val engine = if (preferGoogle && isInstalled("com.google.android.tts")) "com.google.android.tts" else null
        tts = TextToSpeech(applicationContext, { status -> handler.post { onTtsInit(status, engine) } }, engine)
    }

    private fun onTtsInit(status: Int, engine: String?) {
        if (status != TextToSpeech.SUCCESS) {
            try {
                tts?.shutdown()
            } catch (_: Throwable) {
            }
            tts = null
            if (engine != null) {
                initTts(false)
            } else if (active) {
                finishReading("Text to speech isn't available on this phone")
            }
            return
        }
        val t = tts ?: return
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setOnUtteranceProgressListener(utteranceListener)
        chooseVoice()
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        ttsReady = true
        if (active && wantPlay && !started && segments.isNotEmpty()) speakFrom(0)
    }

    private fun englishVoices(): List<Voice> {
        val t = tts ?: return emptyList()
        val all: Set<Voice> = try {
            t.voices ?: return emptyList()
        } catch (e: Exception) {
            return emptyList()
        }
        return all.filter { v ->
            val f = v.features
            v.locale.language == "en" && (f == null || !f.contains("notInstalled"))
        }
    }

    private fun score(v: Voice): Int {
        var s = v.quality / 10
        s += when (v.locale.country) {
            "IN" -> 300
            "GB" -> 200
            "US" -> 150
            "AU" -> 120
            else -> 0
        }
        if (v.isNetworkConnectionRequired) s -= 60
        return s
    }

    private fun chooseVoice() {
        val t = tts ?: return
        val voices = englishVoices()
        val saved = prefs.getString("voice", null)
        val pick = voices.firstOrNull { it.name == saved } ?: voices.maxByOrNull { score(it) }
        try {
            if (pick != null) t.setVoice(pick) else t.setLanguage(Locale("en", "IN"))
        } catch (_: Exception) {
        }
    }

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            handler.post { onUttStart(utteranceId) }
        }

        override fun onDone(utteranceId: String?) {
            handler.post { onUttDone(utteranceId) }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            handler.post { onUttError(utteranceId) }
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            handler.post { onUttError(utteranceId) }
        }
    }

    // ------------------------------------------------------------------ earphones, lock screen, notification

    private val sessionCallback = object : MediaSessionCompat.Callback() {
        override fun onPlay() = play()
        override fun onPause() = pause()
        override fun onSkipToNext() = next()
        override fun onSkipToPrevious() = previous()
        override fun onFastForward() = nextParagraph()
        override fun onRewind() = previousParagraph()
        override fun onStop() = stopReading()

        override fun onMediaButtonEvent(mediaButtonEvent: Intent?): Boolean {
            val intent = mediaButtonEvent ?: return false
            val ev = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                ?: return false
            if (ev.action != KeyEvent.ACTION_DOWN) return true
            when (ev.keyCode) {
                // one tap = pause / play, two taps = next part, three taps = previous part
                KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (ev.repeatCount == 0) {
                        tapCount++
                        handler.removeCallbacks(tapRunnable)
                        handler.postDelayed(tapRunnable, 380)
                    }
                }
                KeyEvent.KEYCODE_MEDIA_NEXT -> next()
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> previous()
                KeyEvent.KEYCODE_MEDIA_PLAY -> play()
                KeyEvent.KEYCODE_MEDIA_PAUSE -> pause()
                KeyEvent.KEYCODE_MEDIA_STOP -> stopReading()
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> nextParagraph()
                KeyEvent.KEYCODE_MEDIA_REWIND -> previousParagraph()
                else -> return false
            }
            return true
        }
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnGain = false
                pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (wantPlay) {
                    resumeOnGain = true
                    pause(keepFocus = true)
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                if (resumeOnGain) {
                    resumeOnGain = false
                    play()
                }
            }
        }
    }

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) pause()
        }
    }

    private fun registerNoisy() {
        if (noisyRegistered) return
        ContextCompat.registerReceiver(
            this, noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        noisyRegistered = true
    }

    private fun unregisterNoisy() {
        if (!noisyRegistered) return
        try {
            unregisterReceiver(noisyReceiver)
        } catch (_: Exception) {
        }
        noisyRegistered = false
    }

    private fun requestFocus() {
        try {
            val attrs = AudioAttributesCompat.Builder()
                .setUsage(AudioAttributesCompat.USAGE_MEDIA)
                .setContentType(AudioAttributesCompat.CONTENT_TYPE_SPEECH)
                .build()
            val req = AudioFocusRequestCompat.Builder(AudioManagerCompat.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            AudioManagerCompat.requestAudioFocus(audioManager, req)
            focusReq = req
        } catch (_: Throwable) {
        }
    }

    private fun abandonFocus() {
        val req = focusReq ?: return
        try {
            AudioManagerCompat.abandonAudioFocusRequest(audioManager, req)
        } catch (_: Throwable) {
        }
        focusReq = null
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "drivepdf:readaloud")
                    .apply { setReferenceCounted(false) }
            }
            if (wakeLock?.isHeld == false) wakeLock?.acquire(6 * 60 * 60 * 1000L)
            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "drivepdf:readaloud")
                    .apply { setReferenceCounted(false) }
            }
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
        } catch (_: Throwable) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Throwable) {
        }
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Throwable) {
        }
    }

    private fun updatePlaybackState() {
        val state = when {
            !active -> PlaybackStateCompat.STATE_STOPPED
            loading -> PlaybackStateCompat.STATE_BUFFERING
            wantPlay -> PlaybackStateCompat.STATE_PLAYING
            else -> PlaybackStateCompat.STATE_PAUSED
        }
        val actions = PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_STOP or
            PlaybackStateCompat.ACTION_FAST_FORWARD or PlaybackStateCompat.ACTION_REWIND
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(
                    state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN,
                    if (state == PlaybackStateCompat.STATE_PLAYING) 1f else 0f
                )
                .build()
        )
    }

    private fun updateMetadata(caption: String) {
        session.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, caption.take(120))
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, docName)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "Read aloud")
                .build()
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Read aloud", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun actionIntent(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, ReadAloudService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val seg = segments.getOrNull(cursor)
        val text = when {
            seg != null -> seg.raw
            loading -> "Getting the text ready…"
            else -> "Read aloud"
        }
        val playing = active && wantPlay
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(if (docName.isEmpty()) "Read aloud" else docName)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(R.drawable.ic_skip_prev, "Previous", actionIntent(ACTION_PREV, 1))
            .addAction(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play,
                if (playing) "Pause" else "Play",
                actionIntent(ACTION_TOGGLE, 2)
            )
            .addAction(R.drawable.ic_skip_next, "Next", actionIntent(ACTION_NEXT, 3))
            .addAction(R.drawable.ic_close, "Stop", actionIntent(ACTION_STOP, 4))
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setMediaSession(session.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()
    }

    private fun ensureForeground(): Boolean = try {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
        true
    } catch (e: Exception) {
        false
    }

    private var lastNotify = 0L

    private fun refreshNotification(force: Boolean = false) {
        if (!active) return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastNotify < 700) return
        lastNotify = now
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (_: Throwable) {
        }
    }

    private fun publish(message: String?) {
        val seg = segments.getOrNull(cursor)
        val page = seg?.page ?: startPage
        val first = pageStart[page] ?: 0
        ReadAloud.publish(
            ReadAloud.State(
                active = active,
                playing = active && wantPlay,
                loading = loading,
                path = path,
                docName = docName,
                page = page,
                pageCount = pageCount,
                caption = seg?.raw ?: "",
                partInPage = if (seg != null) cursor - first + 1 else 0,
                partsInPage = pageParts[page] ?: 0,
                rate = rate,
                message = message
            )
        )
    }
}

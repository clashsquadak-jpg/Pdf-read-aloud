package com.example.drivepdf

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

/** Pulls the text of one page at a time out of a PDF, for Read aloud. Not thread-safe: use from one thread. */
class PdfTextExtractor(context: Context, file: File) {

    private val doc: PDDocument
    val pageCount: Int
    private var prevFirst = ""
    private var prevLast = ""

    init {
        PDFBoxResourceLoader.init(context.applicationContext)
        doc = PDDocument.load(file)
        pageCount = doc.numberOfPages
    }

    private val pageNumberRe = Regex("""(?i)^(page\s*)?\d{1,4}(\s*(of|/)\s*\d{1,4})?$""")
    private val digitsRe = Regex("""\d+""")

    private fun key(line: String): String = digitsRe.replace(line.lowercase().trim(), "#")

    /** Text of page [index] (0-based) as speakable parts, in reading order. */
    fun extractPage(index: Int): List<SegDraft> {
        val stripper = PDFTextStripper()
        stripper.setStartPage(index + 1)
        stripper.setEndPage(index + 1)
        stripper.setSortByPosition(false)
        stripper.setParagraphEnd("\u2029")
        stripper.setLineSeparator("\n")
        val text = stripper.getText(doc) ?: return emptyList()

        val paras = ArrayList<MutableList<String>>()
        for (p in text.split('\u2029')) {
            val lines = p.split('\n').map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
            if (lines.isNotEmpty()) paras.add(lines)
        }
        if (paras.isEmpty()) return emptyList()

        // running headers, footers and page numbers are not read out
        val first = paras.first().first()
        val last = paras.last().last()
        val firstKey = key(first)
        val lastKey = key(last)
        val dropFirst = (firstKey.isNotEmpty() && firstKey == prevFirst && first.length < 90) ||
            pageNumberRe.matches(first)
        val dropLast = (lastKey.isNotEmpty() && lastKey == prevLast && last.length < 90) ||
            pageNumberRe.matches(last)
        prevFirst = firstKey
        prevLast = lastKey
        if (dropFirst) {
            paras.first().removeAt(0)
            if (paras.first().isEmpty()) paras.removeAt(0)
        }
        if (dropLast && paras.isNotEmpty()) {
            paras.last().removeAt(paras.last().size - 1)
            if (paras.last().isEmpty()) paras.removeAt(paras.size - 1)
        }
        if (paras.isEmpty()) return emptyList()
        return SpeechText.toDrafts(paras)
    }

    fun close() {
        try {
            doc.close()
        } catch (_: Exception) {
        }
    }
}

package com.example.drivepdf

import java.text.Normalizer

/** One thing to read aloud: [raw] is what the screen shows, [speak] is what the voice says. */
class SegDraft(val raw: String, val speak: String, val para: Int, val pauseMs: Int)

/**
 * Turns text extracted from a PDF into speakable parts: joins broken lines, drops page furniture,
 * splits into sentences / list items / headings / equations, and rewrites maths and statistics
 * notation into words (x̄ -> "x bar", Σ -> "the sum of", x² -> "x squared", ...).
 */
object SpeechText {

    // ------------------------------------------------------------------ tables

    private const val SUP_FROM = "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻ⁿⁱ"
    private const val SUP_TO = "0123456789+-ni"
    private const val SUB_FROM = "₀₁₂₃₄₅₆₇₈₉₊₋ₙᵢⱼₖₘₐₑₒₓ"
    private const val SUB_TO = "0123456789+-nijkmaeox"

    private val FRACTIONS = mapOf(
        '½' to " one half ", '⅓' to " one third ", '⅔' to " two thirds ", '¼' to " one quarter ",
        '¾' to " three quarters ", '⅕' to " one fifth ", '⅛' to " one eighth "
    )

    private val GREEK = mapOf(
        'α' to "alpha", 'β' to "beta", 'γ' to "gamma", 'δ' to "delta", 'ε' to "epsilon", 'ϵ' to "epsilon",
        'ζ' to "zeta", 'η' to "eta", 'θ' to "theta", 'ϑ' to "theta", 'ι' to "iota", 'κ' to "kappa",
        'λ' to "lambda", 'μ' to "mu", 'µ' to "mu", 'ν' to "nu", 'ξ' to "xi", 'ο' to "omicron", 'π' to "pi",
        'ρ' to "rho", 'σ' to "sigma", 'ς' to "sigma", 'τ' to "tau", 'υ' to "upsilon", 'φ' to "phi",
        'ϕ' to "phi", 'χ' to "chi", 'ψ' to "psi", 'ω' to "omega",
        'Γ' to "gamma", 'Δ' to "delta", 'Θ' to "theta", 'Λ' to "lambda", 'Ξ' to "xi", 'Φ' to "phi",
        'Ψ' to "psi", 'Ω' to "omega", '∆' to "delta"
    )

    private val SYMBOLS = mapOf(
        '≠' to "is not equal to", '≈' to "is approximately equal to", '≅' to "is approximately equal to",
        '≡' to "is equivalent to", '≤' to "is less than or equal to", '⩽' to "is less than or equal to",
        '≥' to "is greater than or equal to", '⩾' to "is greater than or equal to",
        '<' to "is less than", '>' to "is greater than", '≪' to "is much less than", '≫' to "is much greater than",
        '±' to "plus or minus", '∓' to "minus or plus", '×' to "times", '⋅' to "times", '∙' to "times",
        '÷' to "divided by", '∞' to "infinity", '√' to "square root of", '∛' to "cube root of",
        '∑' to "the sum of", 'Σ' to "the sum of", '∏' to "the product of", 'Π' to "the product of",
        '∫' to "the integral of", '∂' to "partial", '∇' to "nabla", '∈' to "belongs to",
        '∉' to "does not belong to", '⊂' to "is a subset of", '⊆' to "is a subset of or equal to",
        '∪' to "union", '∩' to "intersection", '∅' to "empty set", '∀' to "for all", '∃' to "there exists",
        '→' to "tends to", '⟶' to "tends to", '⇒' to "implies", '⇔' to "if and only if",
        '↔' to "if and only if", '∝' to "is proportional to", '−' to "minus", '°' to "degrees",
        '′' to "prime", '″' to "double prime", '‰' to "per mille", '∴' to "therefore", '∵' to "because",
        '⊥' to "is perpendicular to", '∠' to "angle", '=' to "equals", '+' to "plus", '%' to "percent",
        '&' to "and", '@' to "at", '$' to "dollars", '£' to "pounds", '€' to "euros", '₹' to "rupees"
    )

    private val KEEP: Set<String> = (
        "sin cos tan cot sec csc log exp max min var cov sum lim mod gcd lcm det and or the for of to is if " +
            "in on at by as per minus plus times over equals sub squared cubed power root pi bar hat not all " +
            "any are was has can but you its one two ten kg km mg ml cm mm hr hrs sec mph kph usd inr gbp eur " +
            "gdp npv irr roi roe eps cpi wacc cogs vat net tax ytm nav pat pbt ebit yes no may use how why " +
            "who new old our out see set"
        ).split(" ").toSet()

    private val FUNC: Set<String> = "sqrt sinh cosh tanh log exp sigma delta alpha beta gamma theta lambda"
        .split(" ").toSet()

    private const val MATH_CHARS = "=≠≈≤≥<>±∑∏∫√∞×÷^∂∇∈∉⊂∪∩∅∀∃→⇒⇔∝∓≡∴"

    // ------------------------------------------------------------------ regexes

    private val RE_BAR = Regex("""(.)[\u0304\u0305]""")
    private val RE_HAT = Regex("""(.)\u0302""")
    private val RE_TILDE = Regex("""(.)\u0303""")
    private val RE_DOT = Regex("""(.)\u0307""")
    private val RE_ODD_SPACES = Regex("""[\u00a0\u2002\u2003\u2009\u202f]""")
    private val RE_SUP = Regex("""((?<![A-Za-z])[A-Za-zα-ωΑ-Ω]|\d|[)\]])([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻ⁿⁱ]+)""")
    private val RE_SUP_LEFT = Regex("""[⁰¹²³⁴⁵⁶⁷⁸⁹]+""")
    private val RE_SUB = Regex("""([A-Za-zα-ωΑ-Ω])([₀₁₂₃₄₅₆₇₈₉ₙᵢⱼₖₘₐₑₒₓ]+)""")

    private val RE_GREEK_ANY = Regex("""[α-ωΑ-Ω]""")
    private val RE_MATH_OP = Regex("""(?<![A-Za-z])[A-Za-z]\s?[+*/]\s?[A-Za-z0-9(]""")
    private val RE_NUM_OP = Regex("""\d\s?[+*]\s?\d""")

    private val ABBREVIATIONS = listOf(
        Regex("""\be\.g\.""") to "for example",
        Regex("""\bi\.e\.""") to "that is",
        Regex("""\betc\.""") to "etcetera",
        Regex("""\bvs\.""") to "versus",
        Regex("""\bviz\.""") to "namely",
        Regex("""\bcf\.""") to "compare",
        Regex("""\bapprox\.""") to "approximately",
        Regex("""\bFigs?\.""") to "Figure",
        Regex("""\bEqs?\.""") to "Equation",
        Regex("""\bNos?\.(?=\s?\d)""") to "number",
        Regex("""\bp\.a\.""") to "per annum",
        Regex("""\bw\.r\.t\.""") to "with respect to",
        Regex("""\band/or\b""") to "and or"
    )

    private val RE_THOUSANDS = Regex("""(?<=\d),(?=\d{3}(?!\d))""")
    private val RE_RUPEES = Regex("""\b(?:Rs|INR)\.?\s?(\d+(?:\.\d+)?)(\s?(?:crores?|lakhs?|million|billion|thousand))?""")
    private val RE_CURRENCY = Regex("""([\x24£€₹])\s?(\d+(?:\.\d+)?)\s?(million|billion|trillion|thousand|bn|m|k)?(?![A-Za-z])""")
    private val RE_PERCENT = Regex("""(\d)\s?%""")
    private val RE_DEGREES = Regex("""(\d)\s?°\s?([CF])\b""")
    private val RE_RANGE = Regex("""(?<=\d)\s?[–—]\s?(?=\d)""")

    private val RE_SPLIT_VARS = Regex("""(?<![A-Za-z])[a-z]{2,3}(?![A-Za-z])""")
    private val RE_POW2 = Regex("""\^\s?2(?![\d.])""")
    private val RE_POW3 = Regex("""\^\s?3(?![\d.])""")
    private val RE_POW_BRACE = Regex("""\^\s?\{([^{}]*)\}""")
    private val RE_POW_PAREN = Regex("""\^\s?\(([^()]*)\)""")
    private val RE_POW_ANY = Regex("""\^\s?(-?[A-Za-z0-9.]+)""")
    private val RE_SUB_BRACE = Regex("""_\{([^{}]*)\}""")
    private val RE_SUB_ANY = Regex("""_([A-Za-z0-9]+)""")
    private val RE_PROB_GIVEN = Regex("""\bP\(\s*([^()|]+?)\s*\|\s*([^()]+?)\s*\)""")
    private val RE_ABS = Regex("""\|([^|]+)\|""")
    private val RE_VAR = Regex("""\bVar\(""")
    private val RE_COV = Regex("""\bCov\(""")
    private val RE_SD = Regex("""\b(?:SD|Std)\(""")
    private val RE_LN = Regex("""\bln\b""")
    private val RE_FUNC1 = Regex("""\b([fgFGhHPEVNCRSTXYZ])\(([^()]*)\)""")
    private val RE_FUNC2 = Regex("""\b(sin|cos|tan|log|exp)\(([^()]*)\)""")
    private val RE_SLASH = Regex("""\s?/\s?""")
    private val RE_TILDE_DIST = Regex("""\s~\s""")
    private val RE_TILDE_APPROX = Regex("""~\s?(?=\d)""")
    private val RE_MINUS_SPACED = Regex("""\s[-–−]\s""")
    private val RE_MINUS_UNARY = Regex("""(?<![\w)\]])[-−](?=[\w(])""")
    private val RE_MINUS_AFTER_NUM = Regex("""(?<=[\d)\]])[-−](?=[\w(])""")
    private val RE_MINUS_AFTER_LETTER = Regex("""(?<![A-Za-z])([A-Za-z])-(?=[\d(])""")
    private val RE_DIGIT_LETTER = Regex("""\b(\d+(?:\.\d+)?)([A-Za-z]+)\b""")

    private val RE_DATE = Regex("""\b(\d{1,2})/(\d{1,2})/(\d{2,4})\b""")
    private val RE_HALF = Regex("""\b1\s?/\s?2\b""")
    private val RE_THIRD = Regex("""\b1\s?/\s?3\b""")
    private val RE_TWO_THIRDS = Regex("""\b2\s?/\s?3\b""")
    private val RE_QUARTER = Regex("""\b1\s?/\s?4\b""")
    private val RE_THREE_QUARTERS = Regex("""\b3\s?/\s?4\b""")
    private val RE_DIGIT_SLASH = Regex("""(?<=\d)\s?/\s?(?=\d)""")
    private val RE_UNIT_SLASH = Regex("""\b([A-Za-z]{1,3})/([A-Za-z]{1,3})\b""")
    private val RE_WORD_SLASH = Regex("""\b([A-Za-z]{2,})/([A-Za-z]{2,})\b""")

    private val RE_CITATION = Regex("""\[\d+(?:[,–-]\s?\d+)*\]""")
    private val RE_URL = Regex("""https?://\S+""")
    private val RE_EMAIL = Regex("""\S+@\S+\.\S+""")
    private val RE_DASH_PAUSE = Regex("""\s[–—]\s""")
    private val RE_JUNK = Regex("""[•●▪■□◦○‣#_~^|\\]+""")
    private val RE_SPACE_BEFORE_PUNCT = Regex("""\s+([,.;:!?])""")
    private val RE_AFTER_OPEN = Regex("""\(\s+""")
    private val RE_BEFORE_CLOSE = Regex("""\s+\)""")
    private val RE_MANY_SPACES = Regex("""\s{2,}""")

    // ------------------------------------------------------------------ speaking

    private fun sayPower(a: String): String = when (a) {
        "2" -> " squared"
        "3" -> " cubed"
        else -> " to the power of " + a.replace("-", "minus ").replace("+", "plus ")
    }

    private fun mapChars(run: String, from: String, to: String): String {
        val sb = StringBuilder()
        for (c in run) {
            val i = from.indexOf(c)
            if (i >= 0) sb.append(to[i])
        }
        return sb.toString()
    }

    private fun prepare(input: String): String {
        var s = input
        for (ch in charArrayOf('\u00ad', '\u200b', '\u200c', '\u200d', '\ufeff')) s = s.replace(ch.toString(), "")
        s = RE_ODD_SPACES.replace(s, " ")
        s = RE_BAR.replace(s, "$1 bar")
        s = RE_HAT.replace(s, "$1 hat")
        s = RE_TILDE.replace(s, "$1 tilde")
        s = RE_DOT.replace(s, "$1 dot")
        s = s.replace("ȳ", "y bar").replace("Ȳ", "Y bar")
        for ((k, v) in FRACTIONS) s = s.replace(k.toString(), v)
        s = RE_SUP.replace(s) { m -> m.groupValues[1] + sayPower(mapChars(m.groupValues[2], SUP_FROM, SUP_TO)) }
        s = RE_SUP_LEFT.replace(s, "")
        s = RE_SUB.replace(s) { m ->
            val base = m.groupValues[1]
            val a = mapChars(m.groupValues[2], SUB_FROM, SUB_TO)
            if (base == "H" && (a == "0" || a == "1")) "H " + (if (a == "0") "zero" else "one")
            else "$base sub $a"
        }
        return Normalizer.normalize(s, Normalizer.Form.NFKC)
    }

    private fun isMath(s: String): Boolean {
        if (s.any { MATH_CHARS.indexOf(it) >= 0 }) return true
        if (RE_GREEK_ANY.containsMatchIn(s)) return true
        if (RE_MATH_OP.containsMatchIn(s)) return true
        return RE_NUM_OP.containsMatchIn(s)
    }

    private fun abbreviations(input: String): String {
        var s = input
        for ((re, rep) in ABBREVIATIONS) s = re.replace(s, rep)
        return s
    }

    private fun numbersAndCurrency(input: String, math: Boolean): String {
        var s = RE_THOUSANDS.replace(input, "")
        s = RE_RUPEES.replace(s) { m -> m.groupValues[1] + m.groupValues[2] + " rupees" }
        s = RE_CURRENCY.replace(s) { m ->
            val name = when (m.groupValues[1]) {
                "$" -> "dollars"
                "£" -> "pounds"
                "€" -> "euros"
                else -> "rupees"
            }
            val suffix = when (m.groupValues[3].lowercase()) {
                "m", "million" -> " million"
                "bn", "billion" -> " billion"
                "k", "thousand" -> " thousand"
                "trillion" -> " trillion"
                else -> ""
            }
            m.groupValues[2] + suffix + " " + name
        }
        s = RE_PERCENT.replace(s, "$1 percent")
        s = RE_DEGREES.replace(s) { m ->
            m.groupValues[1] + " degrees " + (if (m.groupValues[2] == "C") "Celsius" else "Fahrenheit")
        }
        if (!math) s = RE_RANGE.replace(s, " to ")
        return s
    }

    private fun fractionsAndDates(input: String): String {
        var s = RE_DATE.replace(input, "$1-$2-$3")
        s = RE_HALF.replace(s, "one half")
        s = RE_THIRD.replace(s, "one third")
        s = RE_TWO_THIRDS.replace(s, "two thirds")
        s = RE_QUARTER.replace(s, "one quarter")
        s = RE_THREE_QUARTERS.replace(s, "three quarters")
        return s
    }

    private fun splitVars(input: String): String = RE_SPLIT_VARS.replace(input) { m ->
        val w = m.value
        if (w in KEEP) w else w.toCharArray().joinToString(" ")
    }

    private fun mathRules(input: String, equation: Boolean): String {
        var s = input
        if (equation) s = splitVars(s)
        s = RE_POW2.replace(s, " squared")
        s = RE_POW3.replace(s, " cubed")
        s = RE_POW_BRACE.replace(s, " to the power of $1")
        s = RE_POW_PAREN.replace(s, " to the power of $1")
        s = RE_POW_ANY.replace(s, " to the power of $1")
        s = RE_SUB_BRACE.replace(s, " sub $1")
        s = RE_SUB_ANY.replace(s, " sub $1")
        s = RE_PROB_GIVEN.replace(s, "P of $1 given $2")
        s = RE_ABS.replace(s, "the absolute value of $1")
        s = RE_VAR.replace(s, "variance of (")
        s = RE_COV.replace(s, "covariance of (")
        s = RE_SD.replace(s, "standard deviation of (")
        s = RE_LN.replace(s, "natural log")
        repeat(2) {
            s = RE_FUNC1.replace(s, "$1 of $2")
            s = RE_FUNC2.replace(s, "$1 of $2")
        }
        s = fractionsAndDates(s)
        s = RE_SLASH.replace(s, " over ")
        s = RE_TILDE_DIST.replace(s, " is distributed as ")
        s = RE_TILDE_APPROX.replace(s, "approximately ")
        s = s.replace("*", " times ")
        s = RE_MINUS_SPACED.replace(s, " minus ")
        s = RE_MINUS_UNARY.replace(s, " minus ")
        s = RE_MINUS_AFTER_NUM.replace(s, " minus ")
        s = RE_MINUS_AFTER_LETTER.replace(s, "$1 minus ")
        s = RE_DIGIT_LETTER.replace(s) { m ->
            if (m.groupValues[2].lowercase() in setOf("st", "nd", "rd", "th")) m.value
            else m.groupValues[1] + " " + m.groupValues[2]
        }
        return s
    }

    private fun proseRules(input: String): String {
        var s = fractionsAndDates(input)
        s = RE_DIGIT_SLASH.replace(s, " over ")
        s = s.replace("km/h", "kilometres per hour").replace("m/s", "metres per second")
        s = RE_UNIT_SLASH.replace(s, "$1 per $2")
        s = RE_WORD_SLASH.replace(s, "$1 or $2")
        s = s.replace("*", "")
        s = RE_TILDE_APPROX.replace(s, "approximately ")
        return s
    }

    private fun generalSymbols(input: String): String {
        val s = input.replace("->", " tends to ").replace("=>", " implies ")
        val sb = StringBuilder(s.length + 16)
        for (c in s) {
            val g = GREEK[c]
            val y = SYMBOLS[c]
            when {
                g != null -> sb.append(' ').append(g).append(' ')
                y != null -> sb.append(' ').append(y).append(' ')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun tidy(input: String): String {
        var s = RE_CITATION.replace(input, "")
        s = RE_URL.replace(s, " link ")
        s = RE_EMAIL.replace(s, " email address ")
        s = s.replace('[', '(').replace(']', ')').replace('{', '(').replace('}', ')')
        s = RE_DASH_PAUSE.replace(s, ", ")
        s = RE_JUNK.replace(s, " ")
        s = RE_SPACE_BEFORE_PUNCT.replace(s, "$1")
        s = RE_AFTER_OPEN.replace(s, "(")
        s = RE_BEFORE_CLOSE.replace(s, ")")
        s = RE_MANY_SPACES.replace(s, " ")
        return s.trim()
    }

    /** What the voice should say for one part of the text. */
    fun speak(raw: String, equation: Boolean = false): String {
        var s = prepare(raw)
        val math = isMath(s)
        s = abbreviations(s)
        s = numbersAndCurrency(s, math)
        s = if (math) mathRules(s, equation) else proseRules(s)
        s = generalSymbols(s)
        return tidy(s)
    }

    // ------------------------------------------------------------------ blocks and sentences

    private val BULLET_RE = Regex("""^(?:[•●▪■□◦○‣∙·*]\s*|[-–—]\s+|\(?(?:\d{1,2}|[a-zA-Z]|[ivxIVX]{1,4})[.)]\s+)""")
    private val SYM_BULLET_RE = Regex("""^(?:[•●▪■□◦○‣∙·*]\s*|[-–—]\s+)""")
    private val ABBR_PROTECT = Regex("""\b(?:e\.g|i\.e|etc|vs|viz|cf|Figs?|Eqs?|Nos?|Dr|Mr|Mrs|Ms|Prof|approx|Rs|Ch|Sec|Vol|Inc|Ltd|Co|St|Jr|Sr|al|resp|incl|pp)\.""")
    private val INITIAL_PROTECT = Regex("""\b[A-Z]\.(?=\s?[A-Z])""")
    private val LEAD_PROTECT = Regex("""^\(?(?:\d{1,2}|[a-zA-Z]|[ivxIVX]{1,4})[.)]""")
    private val SENT_SPLIT = Regex("""([.!?]["”’)\]]*)\s+(?=["“‘(\[]*[A-Z0-9])""")
    private val RE_NUMBERED_HEAD = Regex("""^\d+(\.\d+)*\.?\s+\S""")
    private val RE_WORD4 = Regex("""[A-Za-z]{4,}""")
    private val SMALL_WORDS = setOf("of", "and", "the", "in", "for", "to", "a", "an", "on", "or", "at", "by", "with", "as")

    private const val DOT_MASK = '\uE000'

    private class Block(var text: String, val list: Boolean)

    private fun joinLines(a: String, b: String): String {
        if (a.endsWith("-") && a.length > 1 && a[a.length - 2].isLetter()) {
            return if (b.isNotEmpty() && b[0].isLowerCase()) a.dropLast(1) + b else a + b
        }
        return "$a $b"
    }

    private fun endsSentence(t: String): Boolean = t.isNotEmpty() && "\u002e!?:;\"”)".indexOf(t.last()) >= 0

    private fun buildBlocks(paragraphs: List<List<String>>): List<Block> {
        val blocks = ArrayList<Block>()
        for (lines in paragraphs) {
            var cur: Block? = null
            for (line in lines) {
                val l = line.trim()
                if (l.isEmpty()) continue
                val m = BULLET_RE.find(l)
                if (m != null) {
                    if (cur != null) blocks.add(cur)
                    val sym = SYM_BULLET_RE.find(l)
                    cur = Block(if (sym != null) l.substring(sym.range.last + 1) else l, true)
                } else if (cur == null) {
                    cur = Block(l, false)
                } else {
                    cur.text = joinLines(cur.text, l)
                }
            }
            if (cur != null) blocks.add(cur)
        }
        // a sentence that was cut by a paragraph break goes back together
        val merged = ArrayList<Block>()
        for (b in blocks) {
            val prev = merged.lastOrNull()
            if (prev != null && !b.list && !prev.list && !endsSentence(prev.text) &&
                b.text.isNotEmpty() && b.text[0].isLowerCase()
            ) {
                prev.text = joinLines(prev.text, b.text)
            } else {
                merged.add(b)
            }
        }
        return merged
    }

    private fun proseWords(t: String): Int =
        RE_WORD4.findAll(t).count { it.value.lowercase() !in FUNC }

    private fun isEquation(t: String): Boolean =
        t.length <= 170 && t.any { MATH_CHARS.indexOf(it) >= 0 || GREEK.containsKey(it) } && proseWords(t) <= 1

    private fun isHeading(t: String): Boolean {
        if (t.length > 90 || t.length < 2 || ".!?;,:".indexOf(t.last()) >= 0) return false
        val words = t.split(Regex("""\s+""")).filter { it.isNotEmpty() }
        if (words.size > 10 || isEquation(t)) return false
        if (RE_NUMBERED_HEAD.containsMatchIn(t)) return true
        val letters = t.filter { it.isLetter() }
        if (letters.isNotEmpty() && letters.count { it.isUpperCase() }.toFloat() / letters.length > 0.6f) return true
        val cap = words.count { it[0].isUpperCase() || it[0].isDigit() || it.lowercase() in SMALL_WORDS }
        return words.size >= 2 && cap.toFloat() / words.size >= 0.8f
    }

    private fun maskDots(re: Regex, text: String): String =
        re.replace(text) { m -> m.value.replace('.', DOT_MASK) }

    private fun splitSentences(block: String): List<String> {
        var t = maskDots(LEAD_PROTECT, block)
        t = maskDots(ABBR_PROTECT, t)
        t = maskDots(INITIAL_PROTECT, t)
        val out = ArrayList<String>()
        var last = 0
        for (m in SENT_SPLIT.findAll(t)) {
            val end = m.range.first + m.groupValues[1].length
            out.add(t.substring(last, end))
            last = m.range.last + 1
        }
        out.add(t.substring(last))
        return out.map { it.replace(DOT_MASK, '.').trim() }.filter { it.isNotEmpty() }
    }

    private fun chunkLong(input: String, limit: Int = 260): List<String> {
        val res = ArrayList<String>()
        var s = input
        while (s.length > limit) {
            var cut = -1
            for (sep in listOf("; ", ": ", ", ")) {
                val i = s.lastIndexOf(sep, limit - 20)
                if (i >= 80) {
                    cut = i + 1
                    break
                }
            }
            if (cut < 0) {
                cut = s.lastIndexOf(' ', limit - 20)
                if (cut < 80) cut = limit
            }
            res.add(s.substring(0, cut).trim())
            s = s.substring(cut).trim()
        }
        if (s.isNotEmpty()) res.add(s)
        return res
    }

    /** [paragraphs] = paragraphs of one page, each a list of text lines in reading order. */
    fun toDrafts(paragraphs: List<List<String>>): List<SegDraft> {
        val drafts = ArrayList<SegDraft>()
        val blocks = buildBlocks(paragraphs)
        for ((pi, b) in blocks.withIndex()) {
            val text = b.text
            val kind = when {
                isEquation(text) -> 'e'
                !b.list && isHeading(text) -> 'h'
                b.list -> 'l'
                else -> 'p'
            }
            val pause = when (kind) {
                'e' -> 400
                'h' -> 600
                'l' -> 300
                else -> 450
            }
            val sentences = if (kind == 'e') listOf(text) else splitSentences(text)
            val parts = ArrayList<String>()
            for (sn in sentences) parts.addAll(chunkLong(sn))
            for ((j, p) in parts.withIndex()) {
                var sp = speak(p, kind == 'e')
                if (kind == 'h' && sp.isNotEmpty() && ".!?".indexOf(sp.last()) < 0) sp += "."
                if (sp.isNotEmpty()) drafts.add(SegDraft(p, sp, pi, if (j == parts.size - 1) pause else 0))
            }
        }
        return drafts
    }
}

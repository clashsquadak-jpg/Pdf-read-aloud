package com.example.drivepdf

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/** Keeps copies of recently opened PDFs inside the app, and remembers which were open together. */
class Library(context: Context) {

    class Session(
        val keys: List<String>,
        val names: List<String>,
        val ratio: Float,
        val pages: List<Int> = emptyList()
    )

    private val prefs = context.getSharedPreferences("library", Context.MODE_PRIVATE)
    private val dir = File(context.filesDir, "docs").apply { mkdirs() }

    fun fileFor(key: String) = File(dir, "$key.pdf")

    fun nameOf(key: String): String = prefs.getString("name_$key", null) ?: "document.pdf"

    /**
     * Copies the PDF into app storage (PdfRenderer needs a real file). The same PDF is only stored
     * once, and if it is already stored nothing is copied at all. [size] may be -1 if unknown.
     */
    fun importPdf(input: InputStream, displayName: String, size: Long): File {
        val head = ByteArray(HEAD_BYTES)
        val n = readFully(input, head)

        if (size > 0) {
            val existing = fileFor(hashOf(size, head, n))
            if (existing.exists() && existing.length() == size) {
                existing.setLastModified(System.currentTimeMillis())
                prefs.edit().putString("name_${existing.nameWithoutExtension}", displayName).apply()
                return existing
            }
        }

        val tmp = File(dir, "tmp_${System.nanoTime()}")
        tmp.outputStream().use { o ->
            o.write(head, 0, n)
            input.copyTo(o, 512 * 1024)
        }
        val key = hash(tmp)
        val target = fileFor(key)
        if (target.exists()) {
            tmp.delete()
        } else if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
        target.setLastModified(System.currentTimeMillis())
        prefs.edit().putString("name_$key", displayName).apply()
        return target
    }

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val r = input.read(buf, total, buf.size - total)
            if (r < 0) break
            total += r
        }
        return total
    }

    private fun hashOf(size: Long, head: ByteArray, n: Int): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(size.toString().toByteArray())
        md.update(head, 0, minOf(n, HEAD_BYTES))
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun hash(f: File): String {
        val head = ByteArray(HEAD_BYTES)
        val n = f.inputStream().use { readFully(it, head) }
        return hashOf(f.length(), head, n)
    }

    /** Most recent first. Sessions whose files are gone are skipped. */
    fun sessions(): List<Session> {
        val out = ArrayList<Session>()
        try {
            val arr = JSONArray(prefs.getString("sessions", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ka = o.getJSONArray("keys")
                val keys = List(ka.length()) { ka.getString(it) }
                if (keys.isEmpty() || keys.any { !fileFor(it).exists() }) continue
                val pa = o.optJSONArray("pages")
                val pages = if (pa != null) List(pa.length()) { pa.optInt(it, 0) } else emptyList()
                out.add(Session(keys, keys.map { nameOf(it) }, o.optDouble("ratio", 0.5).toFloat(), pages))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveSession(s: Session) {
        val list = sessions().filter { it.keys != s.keys }.toMutableList()
        list.add(0, s)
        val kept = list.take(8)
        val arr = JSONArray()
        for (x in kept) {
            arr.put(
                JSONObject()
                    .put("keys", JSONArray(x.keys))
                    .put("ratio", x.ratio.toDouble())
                    .put("pages", JSONArray(x.pages))
            )
        }
        prefs.edit().putString("sessions", arr.toString()).apply()

        // delete stored PDFs that are no longer in any recent session
        val keepKeys = kept.flatMap { it.keys }.toSet()
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { f ->
            val old = now - f.lastModified() > 120_000
            if (f.name.endsWith(".pdf") && f.nameWithoutExtension !in keepKeys && old) f.delete()
            if (f.name.startsWith("tmp_") && now - f.lastModified() > 600_000) f.delete()
        }
    }

    private companion object {
        const val HEAD_BYTES = 256 * 1024
    }
}

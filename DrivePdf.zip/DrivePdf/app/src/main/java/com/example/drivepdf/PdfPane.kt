package com.example.drivepdf

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.util.AttributeSet
import android.util.SparseArray
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/** One PDF view: pages, zoom, page indicator, fast scroller, remembers the last page. */
class PdfPane @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private lateinit var recycler: ZoomRecyclerView
    private lateinit var scroller: FastScroller
    private lateinit var pill: TextView
    private lateinit var closeBtn: TextView

    private val d = context.resources.displayMetrics.density
    private val vMarginPx = (4 * d).toInt()
    private val sideMarginPx = (8 * d).toInt()

    private val handler = Handler(Looper.getMainLooper())
    private val prefs = context.getSharedPreferences("pdf_positions", Context.MODE_PRIVATE)
    private val hidePill = Runnable {
        pillShown = false
        pill.animate().alpha(0f).setDuration(300).start()
    }

    private var doc: PdfDoc? = null
    private var collapsed = false
    private var released = false
    private var lastPillPage = -1
    private var pillShown = false
    private var lastPillPost = 0L
    private var lastFirst = -1
    private var lastLast = -1

    @Volatile
    var file: File? = null
        private set

    var key: String? = null
        private set

    var onTap: (() -> Unit)? = null
    var onTouched: ((PdfPane) -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var onLoaded: ((PdfPane) -> Unit)? = null
    var onFailed: ((PdfPane, String) -> Unit)? = null

    val hasDoc: Boolean get() = doc != null

    private val readapt = Runnable {
        val ad = recycler.adapter as? PageAdapter ?: return@Runnable
        val w = recycler.width
        if (w > (80 * d).toInt() && w != ad.itemWidth) {
            val lm = recycler.layoutManager as LinearLayoutManager
            val pos = lm.findFirstVisibleItemPosition().coerceAtLeast(0)
            ad.setItemWidth(w)
            lm.scrollToPositionWithOffset(pos, 0)
            lastFirst = -1
            recycler.post { updateScroller(false) }
        }
    }

    private val qualityRun = Runnable {
        (recycler.adapter as? PageAdapter)?.setQuality(if (recycler.scale > 1.25f) 2f else 1f)
    }

    init {
        LayoutInflater.from(context).inflate(R.layout.view_pane, this, true)
        recycler = findViewById(R.id.recycler)
        scroller = findViewById(R.id.fastScroller)
        pill = findViewById(R.id.pill)
        closeBtn = findViewById(R.id.closeBtn)

        recycler.layoutManager = LinearLayoutManager(context)
        recycler.itemAnimator = null
        recycler.setHasFixedSize(true)
        recycler.setItemViewCacheSize(4)
        recycler.onTap = { onTap?.invoke() }
        recycler.onTouched = { onTouched?.invoke(this) }
        recycler.onZoomChanged = {
            handler.removeCallbacks(qualityRun)
            handler.postDelayed(qualityRun, 250)
        }
        recycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (doc == null) return
                updateWindow()
                updatePill()
                updateScroller(dy != 0)
                if (dy != 0 && !scroller.dragging) showPill()
            }
        })
        scroller.onDrag = { f -> dragTo(f) }
        closeBtn.setOnClickListener { onClose?.invoke() }
    }

    // Two panes share the same view ids, so don't let Android mix up their saved states.
    override fun dispatchSaveInstanceState(container: SparseArray<Parcelable>) {}
    override fun dispatchRestoreInstanceState(container: SparseArray<Parcelable>) {}

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w != oldw) {
            handler.removeCallbacks(readapt)
            handler.postDelayed(readapt, 250)
        }
    }

    // ---------- loading ----------

    /** page == null means: use the page saved last time for this PDF. */
    fun load(f: File, page: Int?) {
        Exec.io.execute {
            try {
                val d = PdfDoc(f)
                if (d.pageCount == 0) {
                    d.close()
                    fail("This PDF has no pages")
                    return@execute
                }
                val start = page ?: prefs.getInt(f.nameWithoutExtension, 0)
                handler.post { show(d, f, start) }
            } catch (e: SecurityException) {
                fail("Password-protected PDFs aren't supported")
            } catch (e: Exception) {
                fail("Couldn't open this PDF")
            }
        }
    }

    private fun fail(msg: String) {
        handler.post { onFailed?.invoke(this, msg) }
    }

    private fun teardown() {
        (recycler.adapter as? PageAdapter)?.close()
        recycler.adapter = null
        val old = doc
        doc = null
        // closing waits for a page that is mid-render, so never do it on the UI thread
        if (old != null) Exec.io.execute { old.close() }
    }

    private fun show(d: PdfDoc, f: File, page: Int) {
        if (released) {
            Exec.io.execute { d.close() }
            return
        }
        saveProgress()
        teardown()
        doc = d
        file = f
        key = f.nameWithoutExtension
        lastPillPage = -1
        lastFirst = -1
        lastLast = -1
        scroller.hideNow()
        recycler.resetZoom()
        val start = page.coerceIn(0, d.pageCount - 1)
        recycler.doOnLayout {
            if (doc === d && !released) {
                recycler.adapter = PageAdapter(d, recycler.width, sideMarginPx, vMarginPx, start)
                (recycler.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(start, 0)
                recycler.post {
                    updateWindow()
                    updateScroller(false)
                }
                updatePill()
                showPill()
            }
        }
        onLoaded?.invoke(this)
    }

    /** Close the PDF in this pane (the pane itself stays usable). */
    fun clear() {
        saveProgress()
        handler.removeCallbacks(readapt)
        handler.removeCallbacks(qualityRun)
        teardown()
        scroller.hideNow()
        file = null
        key = null
        pill.alpha = 0f
        pillShown = false
        closeBtn.visibility = GONE
    }

    fun release() {
        released = true
        handler.removeCallbacksAndMessages(null)
        teardown()
    }

    /** Jump to the top of page [p] (0-based), used to follow Read aloud. */
    fun scrollToPage(p: Int) {
        val doc = doc ?: return
        (recycler.layoutManager as LinearLayoutManager)
            .scrollToPositionWithOffset(p.coerceIn(0, doc.pageCount - 1), 0)
    }

    // ---------- remembering the last page ----------

    fun saveProgress() {
        val k = key ?: return
        if (doc == null || recycler.adapter == null) return
        val lm = recycler.layoutManager as LinearLayoutManager
        if (lm.findFirstVisibleItemPosition() < 0) return
        prefs.edit().putInt(k, currentPage()).apply()
    }

    fun currentPage(): Int {
        val d = doc ?: return 0
        val lm = recycler.layoutManager as LinearLayoutManager
        var p = lm.findFirstVisibleItemPosition()
        if (p < 0) return 0
        val v = lm.findViewByPosition(p)
        if (v != null && v.bottom < recycler.visibleHeight * 0.4f && p < d.pageCount - 1) p++
        return p
    }

    // ---------- fast scroller ----------

    /** Fast scroller handle was dragged to [f] (0..1): jump there and return the bubble text. */
    private fun dragTo(f: Float): String {
        val ad = recycler.adapter as? PageAdapter ?: return ""
        val maxY = (ad.totalHeight() - recycler.visibleHeight).coerceAtLeast(0f)
        val y = (f * maxY).toLong()
        val p = ad.pageAtY(y)
        val offset = (y - ad.prefixAt(p)).toInt()
        (recycler.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(p, -offset)
        pill.animate().cancel()
        pill.alpha = 0f
        pillShown = false
        val shown = ad.pageAtY(y + (recycler.visibleHeight * 0.4f).toLong())
        return "${shown + 1} / ${ad.itemCount}"
    }

    private fun updateScroller(flash: Boolean) {
        val ad = recycler.adapter as? PageAdapter
        if (ad == null) {
            scroller.update(0f, false)
            return
        }
        val maxY = ad.totalHeight() - recycler.visibleHeight
        if (maxY <= 8 * d) {
            scroller.update(0f, false)
            return
        }
        val lm = recycler.layoutManager as LinearLayoutManager
        val p = lm.findFirstVisibleItemPosition()
        if (p < 0) return
        val v = lm.findViewByPosition(p) ?: return
        val y = ad.prefixAt(p) - (v.top - vMarginPx)
        scroller.update(y / maxY, true)
        if (flash) scroller.flash()
    }

    /** Keeps the handle clear of the split-view divider. */
    fun setScrollerInsets(right: Int, bottom: Int) {
        scroller.rightInset = right
        scroller.bottomInset = bottom
    }

    // ---------- overlay ----------

    private fun updateWindow() {
        val ad = recycler.adapter as? PageAdapter ?: return
        val lm = recycler.layoutManager as LinearLayoutManager
        val f = lm.findFirstVisibleItemPosition()
        val l = lm.findLastVisibleItemPosition()
        if (f >= 0 && l >= f && (f != lastFirst || l != lastLast)) {
            lastFirst = f
            lastLast = l
            ad.setWindow(f, l)
        }
    }

    private fun updatePill() {
        val d = doc ?: return
        val p = currentPage()
        if (p != lastPillPage) {
            lastPillPage = p
            pill.text = "${p + 1} / ${d.pageCount}"
        }
    }

    private fun showPill() {
        if (collapsed) return
        if (!pillShown) {
            pillShown = true
            pill.animate().cancel()
            pill.animate().alpha(1f).setDuration(100).start()
        }
        val now = SystemClock.uptimeMillis()
        if (now - lastPillPost > 250) {
            lastPillPost = now
            handler.removeCallbacks(hidePill)
            handler.postDelayed(hidePill, 1500)
        }
    }

    fun setCollapsed(c: Boolean) {
        collapsed = c
        scroller.visibility = if (c) GONE else VISIBLE
        if (c) {
            closeBtn.visibility = GONE
            pill.alpha = 0f
            pillShown = false
        }
    }

    /** Show or hide the overlay (page number + Close button in split view). */
    fun showControls(show: Boolean, closable: Boolean) {
        handler.removeCallbacks(hidePill)
        closeBtn.fadeTo(show && closable && !collapsed)
        if (show && doc != null && !collapsed) {
            lastPillPage = -1
            updatePill()
            pillShown = true
            pill.animate().cancel()
            pill.animate().alpha(1f).setDuration(100).start()
        } else {
            pillShown = false
            pill.animate().cancel()
            pill.animate().alpha(0f).setDuration(300).start()
        }
    }
}

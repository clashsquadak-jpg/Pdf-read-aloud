package com.example.drivepdf

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.button.MaterialButton
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var library: Library
    private lateinit var splitView: SplitLayout
    private lateinit var paneA: PdfPane
    private lateinit var paneB: PdfPane
    private lateinit var progress: View
    private lateinit var home: View
    private lateinit var recentTitle: View
    private lateinit var recentList: LinearLayout
    private lateinit var controls: View
    private lateinit var splitBtn: View
    private lateinit var readPanel: View
    private lateinit var readCaption: TextView
    private lateinit var readStatus: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnSpeed: TextView
    private lateinit var backCallback: OnBackPressedCallback

    private val handler = Handler(Looper.getMainLooper())
    private val hideControls = Runnable { setControls(false) }
    private val settings by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val readPrefs by lazy { getSharedPreferences("read", MODE_PRIVATE) }

    private var busy = false
    private var controlsOn = false
    private var pickForSecond = false
    private var pendingSplit: PdfPane? = null

    // read aloud
    private var activePane: PdfPane? = null
    private var pendingRead: Triple<String, String, Int>? = null
    private var lastFollowPage = -1
    private var lastFollowPath = ""
    private var lastMessage: String? = null

    /** The pane on the left (or the only one when not split). */
    private val primary: PdfPane get() = splitView.left

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openUri(uri, pickForSecond)
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { launchReading() }

    private val readListener: (ReadAloud.State) -> Unit = { st -> renderRead(st) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = Library(this)
        applyOrientation()
        setContentView(R.layout.activity_main)
        applySystemBars()

        splitView = findViewById(R.id.split)
        paneA = findViewById(R.id.paneA)
        paneB = findViewById(R.id.paneB)
        progress = findViewById(R.id.progress)
        home = findViewById(R.id.home)
        recentTitle = findViewById(R.id.recentTitle)
        recentList = findViewById(R.id.recentList)
        controls = findViewById(R.id.controls)
        splitBtn = findViewById(R.id.splitBtn)
        readPanel = findViewById(R.id.readPanel)
        readCaption = findViewById(R.id.readCaption)
        readStatus = findViewById(R.id.readStatus)
        btnPlay = findViewById(R.id.btnPlay)
        btnSpeed = findViewById(R.id.btnSpeed)
        activePane = paneA

        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "?"
        }
        findViewById<TextView>(R.id.versionText).text = "Version $versionName"

        backCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                goHome()
            }
        }
        onBackPressedDispatcher.addCallback(this, backCallback)

        findViewById<View>(R.id.openButton).setOnClickListener {
            pickForSecond = false
            picker.launch(arrayOf("application/pdf"))
        }
        findViewById<View>(R.id.emptySettingsButton).setOnClickListener { showSettings() }
        findViewById<View>(R.id.settingsBtn).setOnClickListener { showSettings() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { goHome() }
        findViewById<View>(R.id.readBtn).setOnClickListener { startReading() }
        splitBtn.setOnClickListener {
            pickForSecond = true
            setControls(false)
            picker.launch(arrayOf("application/pdf"))
        }

        // read aloud panel (only visible while reading)
        btnPlay.setOnClickListener { ReadAloudService.instance?.togglePlayPause() }
        findViewById<View>(R.id.btnPrev).setOnClickListener { ReadAloudService.instance?.previous() }
        findViewById<View>(R.id.btnNext).setOnClickListener { ReadAloudService.instance?.next() }
        findViewById<View>(R.id.btnParaPrev).setOnClickListener { ReadAloudService.instance?.previousParagraph() }
        findViewById<View>(R.id.btnParaNext).setOnClickListener { ReadAloudService.instance?.nextParagraph() }
        findViewById<View>(R.id.btnStop).setOnClickListener { ReadAloudService.instance?.stopReading() }
        btnSpeed.setOnClickListener { showSpeedDialog() }
        findViewById<View>(R.id.btnVoice).setOnClickListener { showVoiceDialog() }
        findViewById<View>(R.id.btnMore).setOnClickListener { showMoreDialog() }

        val loaded = { p: PdfPane ->
            setBusy(false)
            if (p === pendingSplit) {
                pendingSplit = null
                splitView.setSplit(true)
            }
            saveSession()
            updateHome()
        }
        val failed = { p: PdfPane, msg: String ->
            setBusy(false)
            toast(msg)
            if (p === pendingSplit) pendingSplit = null
            if (splitView.split && !p.hasDoc) {
                splitView.showOnly(if (p === paneA) paneB else paneA)
            }
            updateHome()
        }
        for (p in listOf(paneA, paneB)) {
            p.onTap = {
                activePane = p
                setControls(!controlsOn)
            }
            p.onTouched = { activePane = it }
            p.onLoaded = loaded
            p.onFailed = failed
            p.onClose = { closePane(p) }
        }

        val keys = savedInstanceState?.getStringArrayList("keys")
        val data = intent?.data
        if (keys != null && keys.isNotEmpty()) {
            val ratio = savedInstanceState?.getFloat("ratio", 0.5f) ?: 0.5f
            val pages = savedInstanceState?.getIntegerArrayList("pages") ?: ArrayList<Int>()
            openSession(Library.Session(keys, emptyList(), ratio, pages))
        } else if (intent?.action == Intent.ACTION_VIEW && data != null) {
            openUri(data, false)
        } else {
            // open the last thing you were reading
            val last = library.sessions().firstOrNull()
            if (last != null) openSession(last) else updateHome()
        }
    }

    override fun onStart() {
        super.onStart()
        lastMessage = ReadAloud.state.message
        ReadAloud.addListener(readListener)
    }

    override fun onStop() {
        super.onStop()
        ReadAloud.removeListener(readListener)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) openUri(data, false)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applySystemBars()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applySystemBars()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        currentSession()?.let {
            outState.putStringArrayList("keys", ArrayList(it.keys))
            outState.putFloat("ratio", it.ratio)
            outState.putIntegerArrayList("pages", ArrayList(it.pages))
        }
    }

    override fun onPause() {
        super.onPause()
        paneA.saveProgress()
        paneB.saveProgress()
        saveSession()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        paneA.release()
        paneB.release()
    }

    // ---------- system bars ----------

    /** The phone's status bar is hidden in landscape so the PDF gets the whole screen. */
    private fun applySystemBars() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.statusBars())
        } else {
            controller.show(WindowInsetsCompat.Type.statusBars())
        }
    }

    // ---------- opening files ----------

    private fun openUri(uri: Uri, asSecond: Boolean) {
        setBusy(true)
        Exec.io.execute {
            try {
                val (name, size) = queryInfo(uri)
                val file = contentResolver.openInputStream(uri)!!.use {
                    library.importPdf(it, name, size)
                }
                runOnUiThread {
                    if (asSecond) {
                        pendingSplit = splitView.right
                        splitView.right.load(file, null)
                    } else {
                        splitView.left.load(file, null)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    toast("Couldn't open this file")
                }
            }
        }
    }

    /** File name and size (-1 if the other app doesn't say). */
    private fun queryInfo(uri: Uri): Pair<String, Long> {
        var name: String? = null
        var size = -1L
        try {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {
        }
        val raw = name?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "document.pdf"
        var s = raw.substringAfterLast('/').replace(Regex("[\\\\:*?\"<>|]"), "_")
        if (!s.lowercase().endsWith(".pdf")) s += ".pdf"
        return Pair(s, size)
    }

    private fun openSession(s: Library.Session) {
        val files = s.keys.map { library.fileFor(it) }
        if (files.isEmpty() || files.any { !it.exists() }) {
            toast("That PDF is no longer available")
            updateHome()
            return
        }
        setBusy(true)
        pendingSplit = null
        clearAll()
        if (files.size >= 2) {
            // each side gets back its own page, even if both show the same PDF
            splitView.setSplit(true, s.ratio)
            paneA.load(files[0], s.pages.getOrNull(0))
            paneB.load(files[1], s.pages.getOrNull(1))
        } else {
            paneA.load(files[0], null)
        }
    }

    private fun clearAll() {
        paneA.clear()
        paneB.clear()
        splitView.showOnly(paneA)
    }

    // ---------- recent list / home ----------

    private fun currentSession(): Library.Session? {
        val k1 = primary.key ?: return null
        val keys = mutableListOf(k1)
        val pages = mutableListOf(primary.currentPage())
        var ratio = 0.5f
        if (splitView.split) {
            val second = splitView.right
            val k2 = second.key ?: return null // second PDF still loading
            keys.add(k2)
            pages.add(second.currentPage())
            ratio = splitView.ratio
        }
        return Library.Session(keys, keys.map { library.nameOf(it) }, ratio, pages)
    }

    private fun saveSession() {
        currentSession()?.let { library.saveSession(it) }
    }

    private fun goHome() {
        setControls(false)
        paneA.saveProgress()
        paneB.saveProgress()
        saveSession()
        pendingSplit = null
        ReadAloudService.instance?.stopReading()
        clearAll()
        updateHome()
    }

    private fun updateHome() {
        val show = !primary.hasDoc && !busy
        home.visibility = if (show) View.VISIBLE else View.GONE
        backCallback.isEnabled = primary.hasDoc
        if (show) buildRecents()
    }

    private fun buildRecents() {
        recentList.removeAllViews()
        val list = library.sessions()
        recentTitle.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (s in list) addRow(s)
    }

    private fun addRow(s: Library.Session) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setBackgroundResource(R.drawable.row_bg)
        row.setPadding(dp(16), dp(14), dp(16), dp(14))
        row.isClickable = true
        val tv = TypedValue()
        if (theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
            row.foreground = ContextCompat.getDrawable(this, tv.resourceId)
        }

        val title = TextView(this)
        title.text = s.names.joinToString("   +   ")
        title.textSize = 16f
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        title.setTypeface(null, Typeface.BOLD)
        row.addView(title)

        val sub = TextView(this)
        sub.text = if (s.keys.size > 1) "Split view \u00B7 ${s.keys.size} PDFs" else "PDF"
        sub.textSize = 12f
        sub.alpha = 0.6f
        row.addView(sub)

        row.setOnClickListener { openSession(s) }

        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(8)
        recentList.addView(row, lp)
    }

    // ---------- split view ----------

    private fun closePane(p: PdfPane) {
        if (!splitView.split) return
        setControls(false)
        val reading = ReadAloud.state
        if (reading.active && reading.path == p.file?.absolutePath) {
            ReadAloudService.instance?.stopReading()
        }
        val other = if (p === paneA) paneB else paneA
        p.clear()
        splitView.showOnly(other)
        saveSession()
    }

    // ---------- controls & settings ----------

    private fun setControls(on: Boolean) {
        handler.removeCallbacks(hideControls)
        if (on && !primary.hasDoc) return
        controlsOn = on
        splitBtn.visibility = if (splitView.split) View.GONE else View.VISIBLE
        controls.fadeTo(on)
        paneA.showControls(on, splitView.split)
        paneB.showControls(on, splitView.split)
        if (on) handler.postDelayed(hideControls, 3000)
    }

    private fun applyOrientation() {
        requestedOrientation = when (settings.getString("orientation", "auto")) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun showSettings() {
        val values = arrayOf("auto", "portrait", "landscape")
        val labels = arrayOf("Auto-rotate", "Portrait", "Landscape")
        val current = values.indexOf(settings.getString("orientation", "auto")).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Settings: screen orientation")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                settings.edit().putString("orientation", values[which]).apply()
                applyOrientation()
                dialog.dismiss()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun setBusy(b: Boolean) {
        busy = b
        progress.visibility = if (b) View.VISIBLE else View.GONE
        updateHome()
    }

    // ---------- read aloud ----------

    /** Starts reading the PDF you last touched, from the page you are looking at. */
    private fun startReading() {
        val pane = activePane?.takeIf { it.hasDoc } ?: primary
        val f = pane.file
        if (f == null || !pane.hasDoc) {
            toast("Open a PDF first")
            return
        }
        setControls(false)
        pendingRead = Triple(f.absolutePath, library.nameOf(pane.key ?: ""), pane.currentPage())
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            // needed so the lock screen / notification controls can be shown
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchReading()
        }
    }

    private fun launchReading() {
        val (path, name, page) = pendingRead ?: return
        pendingRead = null
        val i = Intent(this, ReadAloudService::class.java)
            .setAction(ReadAloudService.ACTION_START)
            .putExtra(ReadAloudService.EXTRA_PATH, path)
            .putExtra(ReadAloudService.EXTRA_NAME, name)
            .putExtra(ReadAloudService.EXTRA_PAGE, page)
        try {
            ContextCompat.startForegroundService(this, i)
        } catch (e: Exception) {
            toast("Couldn't start reading")
        }
    }

    private fun renderRead(st: ReadAloud.State) {
        readPanel.visibility = if (st.active) View.VISIBLE else View.GONE
        if (!st.active) {
            lastFollowPage = -1
            lastFollowPath = ""
            val m = st.message
            if (m != null && m != lastMessage) toast(m)
            lastMessage = m
            controls.translationY = 0f
            return
        }
        lastMessage = null
        readCaption.text =
            if (st.caption.isEmpty()) "Getting the text ready\u2026" else st.caption
        readStatus.text = buildString {
            append(st.docName)
            if (st.pageCount > 0) append(" \u00B7 page ${st.page + 1} of ${st.pageCount}")
            if (st.partsInPage > 0) append(" \u00B7 part ${st.partInPage}/${st.partsInPage}")
        }
        btnPlay.setImageResource(if (st.playing) R.drawable.ic_pause else R.drawable.ic_play)
        btnSpeed.text = String.format(Locale.US, "%.1fx", st.rate)

        // scroll the PDF to the page being read
        if (readPrefs.getBoolean("follow", true) && (st.page != lastFollowPage || st.path != lastFollowPath)) {
            lastFollowPage = st.page
            lastFollowPath = st.path
            listOf(paneA, paneB).firstOrNull { it.hasDoc && it.file?.absolutePath == st.path }
                ?.scrollToPage(st.page)
        }
        readPanel.post { controls.translationY = -(readPanel.height + dp(10)).toFloat() }
    }

    private fun showSpeedDialog() {
        val svc = ReadAloudService.instance ?: return
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(12), dp(24), 0)

        val label = TextView(this)
        label.textSize = 16f
        val bar = SeekBar(this)
        bar.max = 25 // 0.5x ... 3.0x in steps of 0.1
        bar.progress = ((svc.rate - 0.5f) * 10f).roundToInt().coerceIn(0, 25)
        fun speedText(p: Int) = "Speed: " + String.format(Locale.US, "%.1fx", 0.5f + p / 10f)
        label.text = speedText(bar.progress)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = speedText(p)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}

            override fun onStopTrackingTouch(sb: SeekBar?) {
                svc.setRate(0.5f + (sb?.progress ?: 0) / 10f)
            }
        })
        box.addView(label)
        box.addView(bar)

        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        for (pr in floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)) {
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            b.text = if (pr == pr.toInt().toFloat()) "${pr.toInt()}x" else "${pr}x"
            b.insetTop = 0
            b.insetBottom = 0
            b.setPadding(dp(4), 0, dp(4), 0)
            b.setOnClickListener {
                bar.progress = ((pr - 0.5f) * 10f).roundToInt()
                label.text = speedText(bar.progress)
                svc.setRate(pr)
            }
            presets.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        plp.topMargin = dp(12)
        box.addView(presets, plp)

        AlertDialog.Builder(this)
            .setTitle("Reading speed")
            .setView(box)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showPitchDialog() {
        val svc = ReadAloudService.instance ?: return
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(12), dp(24), 0)
        val label = TextView(this)
        label.textSize = 16f
        val bar = SeekBar(this)
        bar.max = 16 // 0.6 ... 1.4 in steps of 0.05
        bar.progress = ((svc.pitch - 0.6f) * 20f).roundToInt().coerceIn(0, 16)
        fun pitchText(p: Int) = "Voice pitch: " + String.format(Locale.US, "%.2f", 0.6f + p / 20f)
        label.text = pitchText(bar.progress)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = pitchText(p)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}

            override fun onStopTrackingTouch(sb: SeekBar?) {
                svc.setPitch(0.6f + (sb?.progress ?: 0) / 20f)
            }
        })
        box.addView(label)
        box.addView(bar)
        AlertDialog.Builder(this)
            .setTitle("Voice pitch")
            .setView(box)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showVoiceDialog() {
        val svc = ReadAloudService.instance ?: return
        val options = svc.voiceOptions()
        if (options.isEmpty()) {
            toast("No voices found yet. Install voices in the Text-to-speech settings.")
            openTtsSettings()
            return
        }
        val labels = options.map { it.label }.toTypedArray()
        val checked = options.indexOfFirst { it.selected }
        AlertDialog.Builder(this)
            .setTitle("Choose a voice (tap to hear it)")
            .setSingleChoiceItems(labels, checked) { _, which -> svc.setVoice(options[which].name) }
            .setPositiveButton("Done", null)
            .setNeutralButton("Get more voices") { _, _ -> openTtsSettings() }
            .show()
    }

    private fun showMoreDialog() {
        val svc = ReadAloudService.instance ?: return
        val follow = readPrefs.getBoolean("follow", true)
        val sleep = svc.sleepTimerMinutes()
        val items = arrayOf(
            "Voice pitch",
            if (sleep > 0) "Sleep timer: $sleep min (tap to change)" else "Sleep timer",
            if (follow) "Follow the page while reading: ON" else "Follow the page while reading: OFF",
            "Get more voices"
        )
        AlertDialog.Builder(this)
            .setTitle("Read aloud options")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showPitchDialog()
                    1 -> showSleepDialog()
                    2 -> {
                        readPrefs.edit().putBoolean("follow", !follow).apply()
                        toast(if (follow) "Not following the page" else "Following the page")
                    }
                    3 -> openTtsSettings()
                }
            }
            .show()
    }

    private fun showSleepDialog() {
        val svc = ReadAloudService.instance ?: return
        val minutes = intArrayOf(0, 15, 30, 45, 60, 90)
        val labels = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        AlertDialog.Builder(this)
            .setTitle("Stop reading after")
            .setItems(labels) { _, which ->
                svc.setSleepTimer(minutes[which])
                toast(if (minutes[which] == 0) "Sleep timer off" else "Will stop in ${labels[which]}")
            }
            .show()
    }

    private fun openTtsSettings() {
        val intents = listOf(
            Intent("com.android.settings.TTS_SETTINGS"),
            Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}

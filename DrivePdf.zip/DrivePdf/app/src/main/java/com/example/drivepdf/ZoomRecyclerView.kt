package com.example.drivepdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.os.SystemClock
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt

/** RecyclerView with pinch zoom (0.5x - 4x), double-tap zoom and horizontal panning. */
class ZoomRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RecyclerView(context, attrs) {

    var scale = 1f
        private set
    var onTap: (() -> Unit)? = null
    var onZoomChanged: (() -> Unit)? = null
    var onTouched: (() -> Unit)? = null

    private var posX = 0f
    private var lastX = -1f
    private var paneH = 0
    private val touchMatrix = Matrix()
    private val minScale = 0.5f
    private val maxScale = 4f

    /** Height of the visible content area, in this view's own (unscaled) coordinates. */
    val visibleHeight: Float
        get() = (if (paneH > 0) paneH else height) / scale

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean {
                val now = SystemClock.uptimeMillis()
                val c = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, 0f, 0f, 0)
                superDispatch(c)
                c.recycle()
                return true
            }

            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoomTo(scale * d.scaleFactor, d.focusX, d.focusY, false)
                return true
            }

            override fun onScaleEnd(d: ScaleGestureDetector) {
                applyPadding()
                onZoomChanged?.invoke()
            }
        })

    private val gestureDetector = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onTap?.invoke()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                zoomTo(if (scale > 1.1f || scale < 0.9f) 1f else 2.5f, e.x, e.y, true)
                return true
            }
        })

    init {
        clipToPadding = false
        overScrollMode = OVER_SCROLL_NEVER
    }

    private fun superDispatch(e: MotionEvent) = super.dispatchTouchEvent(e)

    fun resetZoom() {
        scale = 1f
        posX = 0f
        applyPadding()
        invalidate()
    }

    private fun applyPadding() {
        val bottom = if (scale > 1f && paneH > 0) (paneH * (1f - 1f / scale)).toInt() else 0
        setPadding(0, 0, 0, bottom)
        requestLayout()
    }

    private fun clampPos() {
        posX = if (scale <= 1f) {
            width * (1f - scale) / 2f
        } else {
            posX.coerceIn(width * (1f - scale), 0f)
        }
    }

    /** commit = false while the fingers are still pinching: skip the expensive re-layout. */
    private fun zoomTo(target: Float, fx: Float, fy: Float, commit: Boolean) {
        val old = scale
        val ns = target.coerceIn(minScale, maxScale)
        if (ns == old) return
        scale = ns
        posX = fx - (fx - posX) * ns / old
        clampPos()
        if (commit) applyPadding() else if (ns < 1f || old < 1f) requestLayout()
        scrollBy(0, (fy / old - fy / ns).roundToInt())
        invalidate()
        onZoomChanged?.invoke()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val h = View.MeasureSpec.getSize(heightSpec)
        paneH = h
        if (scale < 1f && h > 0 && View.MeasureSpec.getMode(heightSpec) == View.MeasureSpec.EXACTLY) {
            // zoomed out: lay out more content so the scaled-down view still fills the pane
            super.onMeasure(
                widthSpec,
                View.MeasureSpec.makeMeasureSpec((h / scale).toInt(), View.MeasureSpec.EXACTLY)
            )
        } else {
            super.onMeasure(widthSpec, heightSpec)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        clampPos()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        gestureDetector.onTouchEvent(ev)
        if (scaleDetector.isInProgress || ev.pointerCount > 1) {
            lastX = -1f
            return true
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = ev.x
                onTouched?.invoke()
            }
            MotionEvent.ACTION_MOVE -> if (scale > 1f) {
                if (lastX >= 0f) {
                    posX += ev.x - lastX
                    clampPos()
                    invalidate()
                }
                lastX = ev.x
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> lastX = -1f
        }
        touchMatrix.setTranslate(-posX, 0f)
        touchMatrix.postScale(1f / scale, 1f / scale)
        val t = MotionEvent.obtain(ev)
        t.transform(touchMatrix)
        val r = super.dispatchTouchEvent(t)
        t.recycle()
        return r
    }

    override fun dispatchDraw(canvas: Canvas) {
        canvas.save()
        canvas.translate(posX, 0f)
        canvas.scale(scale, scale)
        super.dispatchDraw(canvas)
        canvas.restore()
    }
}

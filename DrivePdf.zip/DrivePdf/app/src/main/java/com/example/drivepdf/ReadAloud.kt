package com.example.drivepdf

/** What the Read aloud service tells the screen. Everything here is used on the main thread. */
object ReadAloud {

    class State(
        val active: Boolean = false,
        val playing: Boolean = false,
        val loading: Boolean = false,
        val path: String = "",
        val docName: String = "",
        val page: Int = 0,
        val pageCount: Int = 0,
        val caption: String = "",
        val partInPage: Int = 0,
        val partsInPage: Int = 0,
        val rate: Float = 1f,
        val message: String? = null
    )

    class VoiceOption(val name: String, val label: String, val selected: Boolean)

    var state = State()
        private set

    private val listeners = LinkedHashSet<(State) -> Unit>()

    fun addListener(l: (State) -> Unit) {
        listeners.add(l)
        l(state)
    }

    fun removeListener(l: (State) -> Unit) {
        listeners.remove(l)
    }

    fun publish(s: State) {
        state = s
        for (l in listeners.toList()) l(s)
    }
}

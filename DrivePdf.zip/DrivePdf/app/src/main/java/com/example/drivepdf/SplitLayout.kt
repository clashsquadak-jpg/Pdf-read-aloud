package com.example.drivepdf

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import com.google.android.material.color.MaterialColors
import kotlin.math.abs

/**
 * Holds two PdfPanes with a draggable divider.
 * Landscape: side by side (left | right). Portrait: stacked (top / bottom).
 * "left" and "right" below mean the first (left or top) and second (right or bottom) pane.
 * ratio = share of the space given to the first pane (0.05 .. 0.95).
 * When one PDF is nearly full size, the other is a thin strip at the end (right or bottom);
 * tapping that strip swaps them, so one tap target always does the switch.
 */
class SplitLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewGroup(context, attrs) {

    private lateinit var first: PdfPane
    private lateinit var second: PdfPane

    lateinit var left: PdfPane
        private set
    lateinit var right: PdfPane
        private set

    private val divider = DividerView(context)
    private val scrimRight = View(context)
    private val density = resources.displayMetrics.density
    private val gutterPx = (12 * density).toInt()
    private val touchPx = (28 * density).toInt()
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    var split = false
        private set
    var ratio = 0.5f
        private set

    /** true in portrait: PDFs are stacked top / bottom instead of side by side */
    private var stacked = false

    private var downPos = 0f
    private var dragging = false
    private var animator: ValueAnimator? = null

    private val collapsedRight: Boolean get() = split && ratio > 0.9f

    override fun onFinishInflate() {
        super.onFinishInflate()
        first = getChildAt(0) as PdfPane
        second = getChildAt(1) as PdfPane
        left = first
        right = second
        right.visibility = View.GONE

        scrimRight.setBackgroundColor(context.getColor(R.color.scrim))
        scrimRight.visibility = View.GONE
        divider.visibility = View.GONE
        scrimRight.setOnClickListener { swapSides() }
        addView(scrimRight)
        addView(divider)

        divider.setOnTouchListener { _, e ->
            val pos = if (stacked) e.rawY else e.rawX
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    animator?.cancel()
                    downPos = pos
                    dragging = false
                    parent.requestDisallowInterceptTouchEvent(true)
                    divider.setGrabbed(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && abs(pos - downPos) > slop) dragging = true
                    if (dragging) {
                        val loc = IntArray(2)
                        getLocationOnScreen(loc)
                        // the finger holds the middle of the gutter
                        val total = (if (stacked) height else width) - gutterPx
                        val start = (if (stacked) loc[1] else loc[0]) + gutterPx / 2f
                        if (total > 0) setRatio((pos - start) / total)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    divider.setGrabbed(false)
                    if (!dragging) {
                        if (collapsedRight) swapSides()
                    } else {
                        settle()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    divider.setGrabbed(false)
                    settle()
                }
            }
            true
        }
    }

    /** Show only this pane, full screen. */
    fun showOnly(p: PdfPane) {
        animator?.cancel()
        left = p
        right = if (p === first) second else first
        split = false
        ratio = 0.5f
        left.visibility = View.VISIBLE
        right.visibility = View.GONE
        divider.visibility = View.GONE
        updateCollapsedState()
        requestLayout()
    }

    fun setSplit(on: Boolean, newRatio: Float = 0.5f) {
        animator?.cancel()
        split = on
        ratio = if (on) newRatio.coerceIn(0.05f, 0.95f) else 0.5f
        val v = if (on) View.VISIBLE else View.GONE
        right.visibility = v
        divider.visibility = v
        updateCollapsedState()
        requestLayout()
    }

    private fun swapSides() {
        val t = left
        left = right
        right = t
        updateCollapsedState()
        requestLayout()
    }

    private fun setRatio(r: Float) {
        ratio = r.coerceIn(0.05f, 0.95f)
        updateCollapsedState()
        requestLayout()
    }

    /** Dragged far enough -> one PDF takes 95%, the other is a 5% strip at the end. */
    private fun settle() {
        when {
            ratio > 0.8f -> animateTo(0.95f)
            ratio < 0.2f -> {
                animator?.cancel()
                swapSides()
                setRatio(0.95f)
            }
        }
    }

    private fun animateTo(target: Float) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(ratio, target).apply {
            duration = 180
            addUpdateListener { setRatio(it.animatedValue as Float) }
            start()
        }
    }

    private fun updateCollapsedState() {
        scrimRight.visibility = if (collapsedRight) View.VISIBLE else View.GONE
        left.setCollapsed(split && ratio < 0.1f)
        right.setCollapsed(collapsedRight)
        // keep the first pane's fast-scroll handle out from under the divider
        val pad = (14 * density).toInt()
        left.setScrollerInsets(
            if (split && !stacked) pad else 0,
            if (split && stacked) pad else 0
        )
        right.setScrollerInsets(0, 0)
    }

    private fun applyOrientation() {
        divider.horizontal = stacked
        updateCollapsedState()
    }

    /** Size of the first pane along the split direction; the gutter sits between the two panes. */
    private fun sizeFirst(total: Int) = if (split) ((total - gutterPx) * ratio).toInt() else total

    private fun exactly(px: Int) = MeasureSpec.makeMeasureSpec(px, MeasureSpec.EXACTLY)

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)

        val nowStacked = h > w
        if (nowStacked != stacked) {
            stacked = nowStacked
            applyOrientation()
        }

        if (stacked) {
            val fh = sizeFirst(h)
            left.measure(exactly(w), exactly(fh))
            if (split) {
                val sh = h - gutterPx - fh
                right.measure(exactly(w), exactly(sh))
                scrimRight.measure(exactly(w), exactly(sh))
                divider.measure(exactly(w), exactly(touchPx))
            }
        } else {
            val fw = sizeFirst(w)
            left.measure(exactly(fw), exactly(h))
            if (split) {
                val sw = w - gutterPx - fw
                right.measure(exactly(sw), exactly(h))
                scrimRight.measure(exactly(sw), exactly(h))
                divider.measure(exactly(touchPx), exactly(h))
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        if (stacked) {
            val fh = sizeFirst(h)
            left.layout(0, 0, w, fh)
            if (split) {
                right.layout(0, fh + gutterPx, w, h)
                scrimRight.layout(0, fh + gutterPx, w, h)
                val c = fh + gutterPx / 2
                divider.layout(0, c - touchPx / 2, w, c + touchPx / 2)
            }
        } else {
            val fw = sizeFirst(w)
            left.layout(0, 0, fw, h)
            if (split) {
                right.layout(fw + gutterPx, 0, w, h)
                scrimRight.layout(fw + gutterPx, 0, w, h)
                val c = fw + gutterPx / 2
                divider.layout(c - touchPx / 2, 0, c + touchPx / 2, h)
            }
        }
    }

    /**
     * The divider: a solid gutter between the two PDFs (like Android's own split screen) with a
     * rounded handle in the middle. It turns blue and the handle grows while you drag it.
     * The view is wider than the gutter so it is easy to grab.
     */
    private class DividerView(context: Context) : View(context) {
        private val d = resources.displayMetrics.density
        private val gutterColor = context.getColor(R.color.divider_bg)
        private val handleColor = context.getColor(R.color.divider_handle)
        private val activeColor = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorPrimary, Color.BLUE
        )
        private val eval = ArgbEvaluator()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var grab = 0f
        private var anim: ValueAnimator? = null

        var horizontal = false
            set(v) {
                field = v
                invalidate()
            }

        fun setGrabbed(g: Boolean) {
            anim?.cancel()
            anim = ValueAnimator.ofFloat(grab, if (g) 1f else 0f).apply {
                duration = 120
                addUpdateListener {
                    grab = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }

        override fun onDraw(canvas: Canvas) {
            val gut = 12 * d
            val cx = width / 2f
            val cy = height / 2f
            val longSide = (40 + 16 * grab) * d
            val shortSide = (4 + 2 * grab) * d

            paint.color = eval.evaluate(grab, gutterColor, activeColor) as Int
            if (horizontal) {
                canvas.drawRect(0f, cy - gut / 2, width.toFloat(), cy + gut / 2, paint)
            } else {
                canvas.drawRect(cx - gut / 2, 0f, cx + gut / 2, height.toFloat(), paint)
            }

            paint.color = eval.evaluate(grab, handleColor, Color.WHITE) as Int
            if (horizontal) {
                canvas.drawRoundRect(
                    cx - longSide / 2, cy - shortSide / 2, cx + longSide / 2, cy + shortSide / 2,
                    shortSide / 2, shortSide / 2, paint
                )
            } else {
                canvas.drawRoundRect(
                    cx - shortSide / 2, cy - longSide / 2, cx + shortSide / 2, cy + longSide / 2,
                    shortSide / 2, shortSide / 2, paint
                )
            }
        }
    }
}
